"""Parametric split keyboard deck and removable mouse wing for the dresser.

The platform preserves the field-tested 21.5 mm drawer-front fit, but uses
larger brackets because typing and mouse-hand forces are much more demanding
than the static loads on the drink organizer.

Installed coordinate system:
    X: left/right along the drawer front
    Y: outward toward the bed (drawer outer face is Y=0)
    Z: upward (drawer top is Z=0)

The keyboard deck is split into two printer-sized halves.  Small plates bolt
under the center seam.  The optional mouse wing bolts to the right edge using
the same joiner plates and has its own extended drawer bracket.  No friction-
only structural joints are used.
"""

from __future__ import annotations

import json
import math
import shutil
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import cadquery as cq
from cadquery import exporters, importers

import drawer_organizer as base


@dataclass(frozen=True)
class PlatformParameters:
    # User-provided approximate device dimensions.
    keyboard_width: float = 444.5       # 17.5 in
    keyboard_depth: float = 127.0       # 5.0 in
    mouse_pad_width: float = 215.9      # 8.5 in
    mouse_pad_depth: float = 203.2      # 8.0 in

    # Platform envelopes.  All individual printable parts fit a 260 mm bed.
    keyboard_platform_width: float = 455.0
    keyboard_platform_depth: float = 142.0
    mouse_platform_width: float = 225.0
    mouse_platform_depth: float = 210.0
    platform_back_y: float = 7.0
    platform_base_thickness: float = 2.4
    platform_base_z: float = -10.0
    rib_height: float = 5.5
    rib_width: float = 2.8
    landing_width: float = 30.0

    # Confirmed/proven drawer fit.
    drawer_front_thickness: float = 20.85
    hook_clearance: float = 21.50
    hook_wall: float = 7.0
    hook_top: float = 8.0
    inner_leg_length: float = 35.0
    outside_leg_length: float = 155.0
    bracket_width: float = 24.0
    shelf_thickness: float = 8.0
    keyboard_shelf_front_y: float = 149.0
    mouse_shelf_front_y: float = 217.0
    keyboard_gusset_drop: float = 122.0
    mouse_gusset_drop: float = 125.0
    gusset_width: float = 12.0
    truss_depth: float = 9.0
    truss_node_radius: float = 10.0
    root_boss_radius: float = 10.0

    # Three keyboard bracket locations avoid assuming a centered third support.
    # The user can edit these X positions if the recessed handle requires it.
    keyboard_bracket_x: Tuple[float, float, float] = (-185.0, 65.0, 185.0)
    keyboard_bolt_y: Tuple[float, float] = (20.0, 115.0)
    mouse_bracket_x: float = 340.0
    mouse_bolt_y: Tuple[float, float] = (20.0, 185.0)

    # M5 bracket and deck-joint hardware.
    bolt_nominal: float = 5.0
    bolt_clearance: float = 0.55
    slot_length: float = 24.0
    bolt_head_diameter: float = 9.2
    bolt_head_recess: float = 3.3
    nut_across_flats: float = 8.2
    nut_clearance: float = 0.35
    nut_thickness: float = 4.2

    # Two identical underside joiners at each seam.
    joiner_length: float = 70.0
    joiner_width: float = 26.0
    joiner_thickness: float = 6.0
    joiner_hole_x: float = 22.0
    joiner_y_positions: Tuple[float, float] = (40.0, 112.0)
    joint_boss_diameter: float = 16.0

    # Contact pad recesses and export quality.
    pad_recess: float = 0.8
    stl_linear_tolerance: float = 0.08
    stl_angular_tolerance: float = 0.12


P = PlatformParameters()
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output" / "v4-keyboard-mouse-platform"
STL_DIR = OUTPUT / "stl"
STEP_DIR = OUTPUT / "step"
RENDER_DIR = OUTPUT / "renders"
REPORT_DIR = OUTPUT / "reports"
DOC_DIR = OUTPUT / "docs"


def make_dirs() -> None:
    for folder in (STL_DIR, STEP_DIR, RENDER_DIR, REPORT_DIR, DOC_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def vertical_cylinder(x: float, y: float, z_min: float, diameter: float, height: float) -> cq.Workplane:
    return (
        cq.Workplane("XY").center(x, y).circle(diameter / 2).extrude(height)
        .translate((0, 0, z_min))
    )


def add_grid_ribs(
    shape: cq.Workplane,
    *,
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    z_min: float,
    p: PlatformParameters = P,
) -> cq.Workplane:
    """Add a sparse orthogonal rib grid beneath a thin, flat top skin."""
    width = x_max - x_min
    depth = y_max - y_min
    x_positions = [x_min + 5.0, x_min + width * 0.25, x_min + width * 0.50,
                   x_min + width * 0.75, x_max - 5.0]
    y_positions = [y_min + 5.0, y_min + depth * 0.30, y_min + depth * 0.60, y_max - 5.0]
    result = shape
    for x in x_positions:
        result = result.union(base.box_xyz(
            p.rib_width, depth, p.rib_height,
            x_center=x, y_min=y_min, z_min=z_min,
        ))
    for y in y_positions:
        result = result.union(base.box_xyz(
            width, p.rib_width, p.rib_height,
            x_center=(x_min + x_max) / 2,
            y_min=y - p.rib_width / 2,
            z_min=z_min,
        ))
    return result


def cut_deck_fastener(
    shape: cq.Workplane,
    x: float,
    y: float,
    p: PlatformParameters = P,
) -> cq.Workplane:
    """Cut a through M5 hole and a flush socket-head recess from the top."""
    rib_bottom = p.platform_base_z - p.rib_height
    top_z = p.platform_base_z + p.platform_base_thickness
    hole_d = p.bolt_nominal + p.bolt_clearance
    shape = shape.cut(vertical_cylinder(x, y, rib_bottom - 1.0, hole_d, top_z - rib_bottom + 2.0))
    shape = shape.cut(vertical_cylinder(
        x, y, top_z - p.bolt_head_recess,
        p.bolt_head_diameter, p.bolt_head_recess + 1.0,
    ))
    return shape


def make_keyboard_half(side: str, p: PlatformParameters = P) -> cq.Workplane:
    """Left or right half of the flat keyboard platform."""
    if side not in ("left", "right"):
        raise ValueError("side must be 'left' or 'right'")
    half_w = p.keyboard_platform_width / 2
    x_min, x_max = ((-half_w, 0.0) if side == "left" else (0.0, half_w))
    center_x = (x_min + x_max) / 2
    y0 = p.platform_back_y
    y1 = y0 + p.keyboard_platform_depth
    rib_z = p.platform_base_z - p.rib_height

    deck = base.box_xyz(
        half_w, p.keyboard_platform_depth, p.platform_base_thickness,
        x_center=center_x, y_min=y0, z_min=p.platform_base_z,
    )
    deck = add_grid_ribs(
        deck, x_min=x_min, x_max=x_max, y_min=y0, y_max=y1,
        z_min=rib_z, p=p,
    )

    # Full-depth landing strips place each bracket directly under a deep rib.
    for bx in p.keyboard_bracket_x:
        if x_min < bx < x_max:
            deck = deck.union(base.box_xyz(
                p.landing_width, p.keyboard_platform_depth, p.rib_height,
                x_center=bx, y_min=y0, z_min=rib_z,
            ))
            for by in p.keyboard_bolt_y:
                deck = deck.cut(base.horizontal_slot_cutter(
                    bx, by, rib_z - 1.0,
                    p.rib_height + p.platform_base_thickness + 2.0,
                    p.slot_length, p.bolt_nominal + p.bolt_clearance,
                ))

    # Center seam: one recessed screw per half at each joiner position.
    center_joint_x = -p.joiner_hole_x if side == "left" else p.joiner_hole_x
    joint_points = [(center_joint_x, y) for y in p.joiner_y_positions]
    # Right edge also accepts the optional mouse wing joiners.
    if side == "right":
        edge_x = half_w - p.joiner_hole_x
        joint_points.extend((edge_x, y) for y in p.joiner_y_positions)
    for x, y in joint_points:
        deck = deck.union(vertical_cylinder(
            x, y, rib_z, p.joint_boss_diameter, p.rib_height,
        ))
        deck = cut_deck_fastener(deck, x, y, p)

    return deck.clean()


def make_mouse_wing(p: PlatformParameters = P) -> cq.Workplane:
    """Removable right-side mouse-pad platform with its own bracket landing."""
    keyboard_right = p.keyboard_platform_width / 2
    x_min = keyboard_right
    x_max = keyboard_right + p.mouse_platform_width
    y0 = p.platform_back_y
    y1 = y0 + p.mouse_platform_depth
    rib_z = p.platform_base_z - p.rib_height
    wing = base.box_xyz(
        p.mouse_platform_width, p.mouse_platform_depth, p.platform_base_thickness,
        x_center=(x_min + x_max) / 2, y_min=y0, z_min=p.platform_base_z,
    )
    wing = add_grid_ribs(
        wing, x_min=x_min, x_max=x_max, y_min=y0, y_max=y1,
        z_min=rib_z, p=p,
    )
    wing = wing.union(base.box_xyz(
        p.landing_width, p.mouse_platform_depth, p.rib_height,
        x_center=p.mouse_bracket_x, y_min=y0, z_min=rib_z,
    ))
    for by in p.mouse_bolt_y:
        wing = wing.cut(base.horizontal_slot_cutter(
            p.mouse_bracket_x, by, rib_z - 1.0,
            p.rib_height + p.platform_base_thickness + 2.0,
            p.slot_length, p.bolt_nominal + p.bolt_clearance,
        ))

    # Two recessed screws connect the wing to identical underside joiner bars.
    edge_x = keyboard_right + p.joiner_hole_x
    for y in p.joiner_y_positions:
        wing = wing.union(vertical_cylinder(
            edge_x, y, rib_z, p.joint_boss_diameter, p.rib_height,
        ))
        wing = cut_deck_fastener(wing, edge_x, y, p)
    return wing.clean()


def make_joiner(p: PlatformParameters = P) -> cq.Workplane:
    """Small two-bolt seam plate; print four for keyboard plus mouse."""
    joiner = base.box_xyz(
        p.joiner_length, p.joiner_width, p.joiner_thickness,
        y_min=-p.joiner_width / 2, z_min=0.0,
    )
    hole_d = p.bolt_nominal + p.bolt_clearance
    nut_flat = p.nut_across_flats + p.nut_clearance
    nut_vertex_d = nut_flat / math.cos(math.radians(30.0))
    for x in (-p.joiner_hole_x, p.joiner_hole_x):
        joiner = joiner.cut(vertical_cylinder(x, 0.0, -1.0, hole_d, p.joiner_thickness + 2.0))
        pocket = (
            cq.Workplane("XY").center(x, 0.0).polygon(6, nut_vertex_d)
            .extrude(p.nut_thickness + 0.35).translate((0, 0, -0.01))
        )
        joiner = joiner.cut(pocket)
    return joiner.clean()


def make_bracket(kind: str, p: PlatformParameters = P) -> cq.Workplane:
    """Reinforced keyboard or extended mouse bracket at local X=0."""
    if kind == "keyboard":
        shelf_front = p.keyboard_shelf_front_y
        bolt_y = p.keyboard_bolt_y
        gusset_drop = p.keyboard_gusset_drop
    elif kind == "mouse":
        shelf_front = p.mouse_shelf_front_y
        bolt_y = p.mouse_bolt_y
        gusset_drop = p.mouse_gusset_drop
    else:
        raise ValueError("kind must be 'keyboard' or 'mouse'")

    shelf_top = p.platform_base_z - p.rib_height
    shelf_bottom = shelf_top - p.shelf_thickness
    inner_y0 = -(p.hook_clearance + p.hook_wall)
    outer = base.box_xyz(
        p.bracket_width, p.hook_wall,
        p.outside_leg_length + p.hook_top,
        y_min=0.0, z_min=-p.outside_leg_length,
    )
    cap = base.box_xyz(
        p.bracket_width,
        p.hook_clearance + 2 * p.hook_wall,
        p.hook_top,
        y_min=inner_y0, z_min=0.0,
    )
    inner = base.box_xyz(
        p.bracket_width, p.hook_wall,
        p.inner_leg_length + p.hook_top,
        y_min=inner_y0, z_min=-p.inner_leg_length,
    )
    shelf = base.box_xyz(
        p.bracket_width, shelf_front - p.hook_wall,
        p.shelf_thickness,
        y_min=p.hook_wall, z_min=shelf_bottom,
    )
    bracket = outer.union(cap).union(inner).union(shelf)

    # An open diagonal truss carries the front shelf load into the long outer
    # leg with far less material than a filled triangular web.  Both endpoints
    # are deliberately embedded inside their receiving member; rounded nodes
    # spread the load instead of relying on a nearly tangent boolean union.
    ay, az = p.hook_wall - 0.5, shelf_bottom - gusset_drop
    by, bz = shelf_front - 16.0, shelf_bottom + 2.0
    dy, dz = by - ay, bz - az
    length = math.hypot(dy, dz)
    ny = -dz / length * p.truss_depth / 2
    nz = dy / length * p.truss_depth / 2
    rib = (
        cq.Workplane("YZ")
        .moveTo(ay + ny, az + nz)
        .lineTo(by + ny, bz + nz)
        .lineTo(by - ny, bz - nz)
        .lineTo(ay - ny, az - nz)
        .close().extrude(p.gusset_width)
        .translate((-p.gusset_width / 2, 0, 0))
    )
    lower_node_raw = (
        cq.Workplane("YZ").center(ay, az).circle(p.truss_node_radius)
        .extrude(p.gusset_width).translate((-p.gusset_width / 2, 0, 0))
    )
    # Clip the rear of the lower node at Y=0 so it cannot project into the
    # drawer-front clearance/contact plane.
    lower_node_clip = base.box_xyz(
        p.gusset_width + 0.2,
        ay + p.truss_node_radius,
        2 * p.truss_node_radius,
        y_min=0.0,
        z_min=az - p.truss_node_radius,
    )
    lower_node = lower_node_raw.intersect(lower_node_clip)

    upper_node_raw = (
        cq.Workplane("YZ").center(by, bz).circle(p.truss_node_radius)
        .extrude(p.gusset_width).translate((-p.gusset_width / 2, 0, 0))
    )
    # Keep the upper node at or below the shelf top so the platform landing
    # remains a flat, non-interfering contact face.
    upper_node_clip = base.box_xyz(
        p.gusset_width + 0.2,
        shelf_front,
        shelf_top - (bz - p.truss_node_radius),
        y_min=0.0,
        z_min=bz - p.truss_node_radius,
    )
    upper_node = upper_node_raw.intersect(upper_node_clip)
    boss = (
        cq.Workplane("YZ")
        .center(p.hook_wall + p.root_boss_radius - 1.0,
                shelf_top - p.root_boss_radius)
        .circle(p.root_boss_radius).extrude(p.bracket_width)
        .translate((-p.bracket_width / 2, 0, 0))
    )
    bracket = bracket.union(rib).union(lower_node).union(upper_node).union(boss)

    bolt_d = p.bolt_nominal + p.bolt_clearance
    nut_flat = p.nut_across_flats + p.nut_clearance
    nut_vertex_d = nut_flat / math.cos(math.radians(30.0))
    for y in bolt_y:
        bracket = bracket.cut(vertical_cylinder(
            0.0, y, shelf_bottom - 1.0, bolt_d, p.shelf_thickness + 2.0,
        ))
        pocket = (
            cq.Workplane("XY").center(0.0, y).polygon(6, nut_vertex_d)
            .extrude(p.nut_thickness + 0.35).translate((0, 0, shelf_bottom - 0.01))
        )
        bracket = bracket.cut(pocket)

    # Flush furniture-pad recesses preserve the nominal hook clearance.
    contact_w = p.bracket_width - 7.0
    bracket = bracket.cut(base.box_xyz(
        contact_w, p.pad_recess, 75.0,
        y_min=-0.01, z_min=-137.0,
    ))
    bracket = bracket.cut(base.box_xyz(
        contact_w, p.pad_recess + 0.01, 22.0,
        y_min=-p.hook_clearance - p.pad_recess,
        z_min=-29.0,
    ))
    bracket = bracket.cut(base.box_xyz(
        contact_w, p.hook_clearance - 2.0, p.pad_recess + 0.01,
        y_min=-p.hook_clearance + 1.0, z_min=-0.01,
    ))
    return bracket.clean()


def make_hook_fit_test(p: PlatformParameters = P) -> cq.Workplane:
    """Small coupon using the same thicker 7 mm hook walls."""
    width = 30.0
    inner_y0 = -(p.hook_clearance + p.hook_wall)
    outer = base.box_xyz(width, p.hook_wall, 46.0, y_min=0.0, z_min=-38.0)
    inner = base.box_xyz(width, p.hook_wall, 33.0, y_min=inner_y0, z_min=-25.0)
    cap = base.box_xyz(width, p.hook_clearance + 2 * p.hook_wall,
                       p.hook_top, y_min=inner_y0, z_min=0.0)
    return outer.union(inner).union(cap).clean()


def oriented(shape: cq.Workplane, mode: str) -> cq.Workplane:
    result = shape
    if mode == "top_face_down":
        result = result.rotate((0, 0, 0), (1, 0, 0), 180)
    elif mode == "side":
        result = result.rotate((0, 0, 0), (0, 1, 0), 90)
    bb = result.val().BoundingBox()
    return result.translate((-bb.xmin, -bb.ymin, -bb.zmin))


def build_parts(p: PlatformParameters = P) -> Dict[str, cq.Workplane]:
    return {
        "keyboard_left": make_keyboard_half("left", p),
        "keyboard_right": make_keyboard_half("right", p),
        "mouse_wing": make_mouse_wing(p),
        "joiner": make_joiner(p),
        "keyboard_bracket": make_bracket("keyboard", p),
        "mouse_bracket": make_bracket("mouse", p),
        "hook_fit_test": make_hook_fit_test(p),
    }


def export_parts(parts: Dict[str, cq.Workplane], p: PlatformParameters = P) -> Dict[str, Path]:
    step_names = {
        "keyboard_left": "keyboard_platform_left_half.step",
        "keyboard_right": "keyboard_platform_right_half.step",
        "mouse_wing": "optional_mouse_platform_right_wing.step",
        "joiner": "underside_seam_joiner_print_4.step",
        "keyboard_bracket": "reinforced_keyboard_bracket_print_3.step",
        "mouse_bracket": "extended_mouse_bracket.step",
        "hook_fit_test": "keyboard_bracket_hook_fit_test_21p5mm.step",
    }
    stl_specs = {
        "keyboard_left": ("keyboard_platform_left_half_top_face_down.stl", "top_face_down"),
        "keyboard_right": ("keyboard_platform_right_half_top_face_down.stl", "top_face_down"),
        "mouse_wing": ("optional_mouse_platform_right_wing_top_face_down.stl", "top_face_down"),
        "joiner": ("underside_seam_joiner_print_4.stl", "base"),
        "keyboard_bracket": ("reinforced_keyboard_bracket_print_3_on_side.stl", "side"),
        "mouse_bracket": ("extended_mouse_bracket_print_on_side.stl", "side"),
        "hook_fit_test": ("keyboard_bracket_hook_fit_test_21p5mm_on_side.stl", "side"),
    }
    files: Dict[str, Path] = {}
    for key, name in step_names.items():
        path = STEP_DIR / name
        exporters.export(parts[key], str(path))
        files[f"step_{key}"] = path
    for key, (name, mode) in stl_specs.items():
        path = STL_DIR / name
        exporters.export(
            oriented(parts[key], mode), str(path),
            tolerance=p.stl_linear_tolerance,
            angularTolerance=p.stl_angular_tolerance,
        )
        files[f"stl_{key}"] = path
    return files


def bolt_reference(x: float, y: float, p: PlatformParameters = P) -> cq.Workplane:
    rib_bottom = p.platform_base_z - p.rib_height
    top_z = p.platform_base_z + p.platform_base_thickness
    shank = vertical_cylinder(x, y, rib_bottom - p.joiner_thickness,
                              p.bolt_nominal, top_z - rib_bottom + p.joiner_thickness)
    head = vertical_cylinder(x, y, top_z - p.bolt_head_recess,
                             p.bolt_head_diameter, p.bolt_head_recess)
    return shank.union(head)


def make_keyboard_assembly(parts: Dict[str, cq.Workplane], p: PlatformParameters = P) -> cq.Assembly:
    assembly = cq.Assembly(name="split_keyboard_platform_three_brackets")
    assembly.add(parts["keyboard_left"], name="keyboard_left", color=cq.Color(0.16, 0.39, 0.65))
    assembly.add(parts["keyboard_right"], name="keyboard_right", color=cq.Color(0.18, 0.43, 0.70))
    rib_bottom = p.platform_base_z - p.rib_height
    for index, y in enumerate(p.joiner_y_positions, 1):
        assembly.add(
            parts["joiner"], name=f"center_joiner_{index}",
            loc=cq.Location(cq.Vector(0, y, rib_bottom - p.joiner_thickness)),
            color=cq.Color(0.10, 0.26, 0.43),
        )
    for index, x in enumerate(p.keyboard_bracket_x, 1):
        assembly.add(
            parts["keyboard_bracket"], name=f"keyboard_bracket_{index}",
            loc=cq.Location(cq.Vector(x, 0, 0)), color=cq.Color(0.10, 0.26, 0.43),
        )
    return assembly


def make_full_assembly(parts: Dict[str, cq.Workplane], p: PlatformParameters = P) -> cq.Assembly:
    assembly = make_keyboard_assembly(parts, p)
    assembly.name = "keyboard_platform_with_removable_mouse_wing"
    assembly.add(parts["mouse_wing"], name="optional_mouse_wing", color=cq.Color(0.24, 0.49, 0.72))
    rib_bottom = p.platform_base_z - p.rib_height
    seam_x = p.keyboard_platform_width / 2
    for index, y in enumerate(p.joiner_y_positions, 1):
        assembly.add(
            parts["joiner"], name=f"mouse_joiner_{index}",
            loc=cq.Location(cq.Vector(seam_x, y, rib_bottom - p.joiner_thickness)),
            color=cq.Color(0.10, 0.26, 0.43),
        )
    assembly.add(
        parts["mouse_bracket"], name="extended_mouse_bracket",
        loc=cq.Location(cq.Vector(p.mouse_bracket_x, 0, 0)),
        color=cq.Color(0.10, 0.26, 0.43),
    )
    return assembly


def export_assemblies(parts: Dict[str, cq.Workplane], p: PlatformParameters = P) -> Dict[str, Path]:
    keyboard_path = STEP_DIR / "keyboard_platform_three_bracket_complete_assembly.step"
    make_keyboard_assembly(parts, p).save(str(keyboard_path), mode="default")
    full_path = STEP_DIR / "keyboard_mouse_platform_complete_assembly.step"
    make_full_assembly(parts, p).save(str(full_path), mode="default")
    return {"step_assembly_keyboard": keyboard_path, "step_assembly_full": full_path}


def render_scene(
    filename: str,
    scene: Sequence[Tuple[cq.Shape, str, float]],
    *, elev: float, azim: float,
    bounds: Sequence[Tuple[float, float]], title: str,
) -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(12, 8), dpi=170)
    ax = fig.add_subplot(111, projection="3d", computed_zorder=False)
    for shape, color, alpha in scene:
        base.add_shape_to_axis(ax, shape, color, alpha)
    base.set_axes_equal(ax, bounds)
    ax.view_init(elev=elev, azim=azim)
    ax.set_axis_off()
    ax.set_title(title, pad=16)
    fig.patch.set_facecolor("#f5f4f0")
    ax.set_facecolor("#f5f4f0")
    plt.tight_layout()
    path = RENDER_DIR / filename
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def assembly_scene(parts: Dict[str, cq.Workplane], include_mouse: bool, p: PlatformParameters = P):
    scene: List[Tuple[cq.Shape, str, float]] = [
        (parts["keyboard_left"].val(), "#2d79bd", 1.0),
        (parts["keyboard_right"].val(), "#347fc0", 1.0),
    ]
    rib_bottom = p.platform_base_z - p.rib_height
    for y in p.joiner_y_positions:
        scene.append((parts["joiner"].translate((0, y, rib_bottom - p.joiner_thickness)).val(),
                      "#173f66", 1.0))
    for x in p.keyboard_bracket_x:
        scene.append((parts["keyboard_bracket"].translate((x, 0, 0)).val(), "#173f66", 1.0))
    if include_mouse:
        scene.append((parts["mouse_wing"].val(), "#4f95c9", 1.0))
        seam_x = p.keyboard_platform_width / 2
        for y in p.joiner_y_positions:
            scene.append((parts["joiner"].translate(
                (seam_x, y, rib_bottom - p.joiner_thickness)).val(), "#173f66", 1.0))
        scene.append((parts["mouse_bracket"].translate((p.mouse_bracket_x, 0, 0)).val(),
                      "#173f66", 1.0))
    return scene


def render_all(parts: Dict[str, cq.Workplane], p: PlatformParameters = P) -> List[Path]:
    keyboard_reference = base.box_xyz(
        p.keyboard_width, p.keyboard_depth, 24.0,
        y_min=p.platform_back_y + (p.keyboard_platform_depth - p.keyboard_depth) / 2,
        z_min=p.platform_base_z + p.platform_base_thickness,
    ).val()
    mouse_pad = base.box_xyz(
        p.mouse_pad_width, p.mouse_pad_depth, 2.5,
        x_center=p.keyboard_platform_width / 2 + p.mouse_platform_width / 2,
        y_min=p.platform_back_y + (p.mouse_platform_depth - p.mouse_pad_depth) / 2,
        z_min=p.platform_base_z + p.platform_base_thickness,
    ).val()
    keyboard_scene = assembly_scene(parts, False, p)
    full_scene = assembly_scene(parts, True, p)
    paths = [
        render_scene(
            "keyboard_platform_three_brackets_isometric.png",
            [*keyboard_scene, (keyboard_reference, "#202329", 0.96)],
            elev=21, azim=-58,
            bounds=((-250, 250), (-50, 180), (-180, 80)),
            title="Split keyboard platform — two deck halves, three reinforced brackets",
        ),
        render_scene(
            "keyboard_mouse_platform_full_isometric.png",
            [*full_scene, (keyboard_reference, "#202329", 0.96), (mouse_pad, "#2d2d30", 0.95)],
            elev=23, azim=-58,
            bounds=((-250, 480), (-55, 240), (-180, 80)),
            title="Full modular setup — removable mouse wing and dedicated support",
        ),
        render_scene(
            "keyboard_mouse_platform_top_layout.png",
            [*full_scene, (keyboard_reference, "#202329", 0.94), (mouse_pad, "#2d2d30", 0.92)],
            elev=88, azim=-90,
            bounds=((-250, 480), (-20, 235), (-30, 50)),
            title="Top layout — 455 mm keyboard deck plus optional 225 x 210 mm mouse wing",
        ),
        render_scene(
            "keyboard_mouse_platform_underside_structure.png",
            full_scene,
            elev=-23, azim=-56,
            bounds=((-250, 480), (-55, 240), (-190, 55)),
            title="Underside — rib grids, four seam joiners, and open truss brackets",
        ),
        render_scene(
            "reinforced_bracket_side_detail.png",
            [(parts["keyboard_bracket"].val(), "#1f5f96", 1.0)],
            elev=0, azim=0,
            bounds=((-25, 25), (-40, 165), (-170, 20)),
            title="Bracket side detail — embedded diagonal and rounded load-spreading nodes",
        ),
    ]

    drawer = base.box_xyz(
        760.0, p.drawer_front_thickness, 200.0,
        x_center=100.0, y_min=-p.drawer_front_thickness, z_min=-200.0,
    ).val()
    handle = base.box_xyz(110.0, 7.0, 25.0, x_center=0.0, y_min=0.0, z_min=-63.0).val()
    installed = [
        (drawer, "#8a552f", 0.78), (handle, "#b7b9bd", 1.0),
        *full_scene, (keyboard_reference, "#202329", 0.96), (mouse_pad, "#2d2d30", 0.95),
    ]
    paths.append(render_scene(
        "installed_position_simplified_drawer.png", installed,
        elev=19, azim=-53,
        bounds=((-320, 500), (-75, 250), (-220, 90)),
        title="Installed visualization — drawer width and handle are illustrative, not measured",
    ))
    return paths


def validate(
    parts: Dict[str, cq.Workplane], files: Dict[str, Path], p: PlatformParameters = P,
) -> Dict:
    import trimesh

    report: Dict = {
        "status": "PASS", "parameters_mm": asdict(p),
        "solid_checks": {}, "mesh_checks": {}, "step_reimport_checks": {},
        "dimensional_checks": {}, "assembly_checks": {}, "mass_estimate": {},
        "engineering_screen": {}, "warnings": [],
    }
    for name, wp in parts.items():
        shape = wp.val()
        bb = shape.BoundingBox()
        entry = {
            "valid": bool(shape.isValid()), "solid_count": len(shape.Solids()),
            "volume_mm3": round(shape.Volume(), 2),
            "bounding_box_mm": [round(bb.xlen, 3), round(bb.ylen, 3), round(bb.zlen, 3)],
        }
        report["solid_checks"][name] = entry
        if not entry["valid"] or entry["solid_count"] != 1 or entry["volume_mm3"] <= 0:
            report["status"] = "FAIL"

    for key, path in files.items():
        if key.startswith("stl_"):
            mesh = trimesh.load_mesh(path, process=True)
            entry = {
                "vertices": int(len(mesh.vertices)), "faces": int(len(mesh.faces)),
                "watertight": bool(mesh.is_watertight),
                "winding_consistent": bool(mesh.is_winding_consistent),
                "volume_mm3": round(abs(float(mesh.volume)), 2),
                "print_envelope_mm": [round(float(v), 3) for v in mesh.extents],
                "fits_260mm_xy": bool(mesh.extents[0] <= 260.0 and mesh.extents[1] <= 260.0),
            }
            report["mesh_checks"][path.name] = entry
            if (not entry["watertight"] or not entry["winding_consistent"]
                    or entry["faces"] == 0 or not entry["fits_260mm_xy"]):
                report["status"] = "FAIL"
        if key.startswith("step_"):
            imported = importers.importStep(str(path)).val()
            entry = {"valid": bool(imported.isValid()), "solid_count": len(imported.Solids()),
                     "volume_mm3": round(imported.Volume(), 2)}
            report["step_reimport_checks"][path.name] = entry
            if not entry["valid"] or entry["solid_count"] < 1:
                report["status"] = "FAIL"

    report["dimensional_checks"] = {
        "keyboard_measured_approx_mm": [p.keyboard_width, p.keyboard_depth],
        "keyboard_platform_mm": [p.keyboard_platform_width, p.keyboard_platform_depth],
        "keyboard_plan_clearance_mm": [
            round(p.keyboard_platform_width - p.keyboard_width, 2),
            round(p.keyboard_platform_depth - p.keyboard_depth, 2),
        ],
        "mouse_pad_measured_approx_mm": [p.mouse_pad_width, p.mouse_pad_depth],
        "mouse_platform_mm": [p.mouse_platform_width, p.mouse_platform_depth],
        "mouse_plan_clearance_mm": [
            round(p.mouse_platform_width - p.mouse_pad_width, 2),
            round(p.mouse_platform_depth - p.mouse_pad_depth, 2),
        ],
        "keyboard_only_required_drawer_width_mm": p.keyboard_platform_width,
        "keyboard_plus_mouse_required_drawer_width_mm": p.keyboard_platform_width + p.mouse_platform_width,
        "hook_clearance_mm": p.hook_clearance,
        "drawer_front_thickness_mm": p.drawer_front_thickness,
        "bare_hook_slack_mm": round(p.hook_clearance - p.drawer_front_thickness, 3),
        "creality_hi_official_build_volume_mm": [260, 260, 300],
    }
    report["brace_connection_checks"] = {
        "diagonal_cross_section_mm": [p.gusset_width, p.truss_depth],
        "rounded_end_node_radius_mm": p.truss_node_radius,
        "lower_endpoint_center_y_mm": p.hook_wall - 0.5,
        "outer_leg_y_range_mm": [0.0, p.hook_wall],
        "upper_endpoint_shelf_inset_mm": 16.0,
        "upper_endpoint_above_shelf_bottom_mm": 2.0,
        "design_intent": "diagonal endpoints overlap receiving members and are united by clipped circular nodes",
    }

    # Verify intended face contacts have no positive-volume overlap.
    rib_bottom = p.platform_base_z - p.rib_height
    left = parts["keyboard_left"].val()
    right = parts["keyboard_right"].val()
    wing = parts["mouse_wing"].val()
    keyboard_bracket_overlap = 0.0
    for x in p.keyboard_bracket_x:
        keyboard_bracket_overlap += (
            left.fuse(right).intersect(parts["keyboard_bracket"].translate((x, 0, 0)).val()).Volume()
        )
    mouse_bracket_overlap = wing.intersect(
        parts["mouse_bracket"].translate((p.mouse_bracket_x, 0, 0)).val()).Volume()
    center_joiner_overlap = sum(
        left.fuse(right).intersect(parts["joiner"].translate(
            (0, y, rib_bottom - p.joiner_thickness)).val()).Volume()
        for y in p.joiner_y_positions
    )
    mouse_joiner_overlap = sum(
        right.fuse(wing).intersect(parts["joiner"].translate(
            (p.keyboard_platform_width / 2, y, rib_bottom - p.joiner_thickness)).val()).Volume()
        for y in p.joiner_y_positions
    )
    report["assembly_checks"] = {
        "left_to_right_deck_overlap_mm3": round(left.intersect(right).Volume(), 6),
        "keyboard_to_mouse_deck_overlap_mm3": round(right.intersect(wing).Volume(), 6),
        "keyboard_bracket_overlap_mm3": round(keyboard_bracket_overlap, 6),
        "mouse_bracket_overlap_mm3": round(mouse_bracket_overlap, 6),
        "center_joiner_overlap_mm3": round(center_joiner_overlap, 6),
        "mouse_joiner_overlap_mm3": round(mouse_joiner_overlap, 6),
        "expected": "zero positive-volume overlap; parts meet at intended planar faces",
    }
    if any(value > 0.001 for value in (
        left.intersect(right).Volume(), right.intersect(wing).Volume(),
        keyboard_bracket_overlap, mouse_bracket_overlap,
        center_joiner_overlap, mouse_joiner_overlap,
    )):
        report["status"] = "FAIL"
        report["warnings"].append("Unexpected positive-volume assembly interference detected.")

    # Fully-solid volume is a conservative filament/mass upper bound.
    density = 1.27
    quantities = {
        "keyboard_left": 1, "keyboard_right": 1, "keyboard_bracket": 3,
        "joiner_keyboard_only": 2, "mouse_wing": 1,
        "mouse_bracket": 1, "additional_joiners_for_mouse": 2,
    }
    masses = {
        name: round(parts[key].val().Volume() / 1000 * density * qty, 1)
        for name, (key, qty) in {
            "keyboard_left_g": ("keyboard_left", 1),
            "keyboard_right_g": ("keyboard_right", 1),
            "three_keyboard_brackets_g": ("keyboard_bracket", 3),
            "two_keyboard_joiners_g": ("joiner", 2),
            "mouse_wing_g": ("mouse_wing", 1),
            "mouse_bracket_g": ("mouse_bracket", 1),
            "two_mouse_joiners_g": ("joiner", 2),
        }.items()
    }
    keyboard_mass = sum(masses[k] for k in (
        "keyboard_left_g", "keyboard_right_g", "three_keyboard_brackets_g",
        "two_keyboard_joiners_g",
    ))
    full_mass = keyboard_mass + masses["mouse_wing_g"] + masses["mouse_bracket_g"] + masses["two_mouse_joiners_g"]
    report["mass_estimate"] = {
        "basis": "fully solid CAD volume at 1.27 g/cm3; sliced mass may be lower",
        **masses,
        "keyboard_only_upper_bound_g": round(keyboard_mass, 1),
        "full_setup_upper_bound_g": round(full_mass, 1),
    }

    # Screening moments deliberately include hand loads, which dominate device mass.
    keyboard_mass_assumed_kg = 1.0
    mouse_and_pad_assumed_kg = 0.25
    keyboard_static_nm = keyboard_mass_assumed_kg * 9.81 * (p.keyboard_platform_depth / 2 / 1000)
    keyboard_hand_nm = 30.0 * (p.keyboard_platform_depth / 1000)
    mouse_static_nm = mouse_and_pad_assumed_kg * 9.81 * (p.mouse_platform_depth / 2 / 1000)
    mouse_hand_nm = 20.0 * (p.mouse_platform_depth / 1000)
    report["engineering_screen"] = {
        "assumptions": {
            "keyboard_mass_kg_unmeasured": keyboard_mass_assumed_kg,
            "mouse_plus_pad_mass_kg_unmeasured": mouse_and_pad_assumed_kg,
            "keyboard_downward_hand_force_N": 30.0,
            "mouse_downward_hand_force_N": 20.0,
        },
        "keyboard_self_weight_moment_Nm": round(keyboard_static_nm, 3),
        "keyboard_hand_force_moment_Nm": round(keyboard_hand_nm, 3),
        "mouse_self_weight_moment_Nm": round(mouse_static_nm, 3),
        "mouse_hand_force_moment_Nm": round(mouse_hand_nm, 3),
        "combined_screening_moment_Nm": round(
            keyboard_static_nm + keyboard_hand_nm + mouse_static_nm + mouse_hand_nm, 3),
        "status": "conservative prototype screen only; not a verified rating",
    }
    return report


def write_docs(p: PlatformParameters = P) -> None:
    instructions = f"""# Keyboard and mouse platform v4 — print and assembly

## Design summary

The keyboard deck is {p.keyboard_platform_width:.0f} x {p.keyboard_platform_depth:.0f} mm and splits
into two {p.keyboard_platform_width / 2:.1f} x {p.keyboard_platform_depth:.0f} mm halves.  The optional
right mouse wing is {p.mouse_platform_width:.0f} x {p.mouse_platform_depth:.0f} mm.  Creality lists the
Hi build volume as 260 x 260 x 300 mm, so every exported part fits without diagonal placement.
Official specification: https://www.creality.com/products/creality-hi-combo

The original organizer brackets should not be used for this platform.  Keyboard and mouse hand forces
are much larger than the static drink-tray load.  This package uses three wider/deeper keyboard brackets
and a separate extended bracket beneath the mouse wing while preserving the proven 21.5 mm hook fit.

## Print in stages to avoid wasting filament

1. You already proved the 21.5 mm clearance, but the small hook coupon is included if desired.
2. Print both keyboard halves, two joiners, and three keyboard brackets.  Do not print the mouse parts yet.
3. Assemble and test the keyboard-only platform over a bed/pillow.
4. If the position is comfortable and the drawer has enough clear width, print the mouse wing, two more
   joiners, and the extended mouse bracket.

The keyboard alone needs approximately {p.keyboard_platform_width:.0f} mm of clear drawer-top width.
The right mouse wing increases this to approximately
{p.keyboard_platform_width + p.mouse_platform_width:.0f} mm.  Measure the real clear width before
printing the mouse parts.  The photographs were not used to invent this unconfirmed dimension.

## Hardware

- Keyboard center seam: 4 x M5 socket-head screws, approximately 16–20 mm; 4 x M5 nuts.
- Three keyboard brackets: 6 x M5 screws with washers, approximately 14–18 mm; 6 x M5 nuts.
- Optional mouse seam: 4 more M5 socket-head screws, 16–20 mm; 4 x M5 nuts.
- Mouse bracket: 2 x M5 screws with washers, approximately 14–18 mm; 2 x M5 nuts.
- Thin TPU/rubber/felt furniture pads for the recessed drawer contact areas.
- Thin nonslip mat or small removable adhesive rubber dots on the flat keyboard/mouse surfaces.

Verify actual screw length against your printed parts before tightening.  Screws must not protrude into
the keyboard or mouse pad.

## Assembly

1. Put M5 nuts into the hex pockets on two joiner plates.
2. Place the joiners beneath the keyboard center seam at the two rows of recessed holes.
3. Insert four M5 screws from the top and tighten gradually, alternating between rows.  The joiners carry
   the seam mechanically; alignment does not depend on friction alone.
4. Load nuts into three keyboard brackets.  Attach them through the six horizontal platform slots.  Start
   with X positions {p.keyboard_bracket_x}; the slots provide fine adjustment.
5. Apply thin protective pads, place all three hooks over the drawer together, and check that none covers
   or loads the recessed handle.
6. For the mouse wing, repeat the joiner process at the right edge, then attach the extended bracket.

## PETG slicer starting point, 0.4 mm nozzle

- 0.20 mm layers; 0.24 mm is acceptable for the hook coupon and joiners.
- Deck halves and mouse wing: 4 walls, 5 top/bottom layers, 18–25% gyroid or cubic infill.
- Brackets and joiners: 6 walls, 6 top/bottom layers, 35–45% gyroid or cubic infill.
- Print deck parts in the exported top-face-down orientation.  The broad keyboard-contact face lies on
  the bed and the reinforcing ribs grow upward without support.
- Print brackets in the exported side orientation.  Use build-plate-only support only if the nut-pocket
  bridges do not print cleanly on your machine.
- PETG should be dry.  Use the filament manufacturer's temperature and cooling guidance rather than a
  universal temperature value.

## Progressive physical test

1. Test the empty platform with the drawer stationary and a pillow underneath.
2. Add the keyboard without typing.  Check bracket seating and drawer-slide movement.
3. Press gently at the rear, center, front edge, and both ends.  Stop if the drawer front, slides, hooks,
   seams, or platform visibly flex, creak, or shift.
4. Type lightly, then normally.  Recheck every fastener after one hour and after 24 hours for PETG creep.
5. Test the mouse wing separately before resting normal hand weight on it.

Never sit, lean your body weight, or use the platform to pull yourself upright.  Keep the drawer stationary
while using it.  This is a prototype accessory, not a certified load-rated desk or medical support.
"""
    (DOC_DIR / "PRINT_AND_ASSEMBLY.md").write_text(instructions, encoding="utf-8")

    engineering = """# Engineering notes

The keyboard mass was not provided.  The screening calculation assumes a 1.0 kg keyboard and a 0.25 kg
mouse plus pad.  More importantly, it includes estimated downward hand loads of 30 N at the keyboard
front edge and 20 N at the mouse-wing front edge.  These hand loads dominate the static device weights.

The screen produces about 0.70 N m from keyboard self-weight, 4.26 N m from keyboard hand force,
0.26 N m from mouse/pad self-weight, and 4.20 N m from mouse hand force: roughly 9.42 N m combined.
This is intentionally conservative and is not a rating.  Real load sharing is nonuniform, and the dresser
front, drawer joints, and slides may govern failure before the printed brackets do.

Three keyboard brackets reduce deck span and lateral rocking.  The optional mouse wing has a dedicated
extended bracket, so its hand load is not carried only by the removable seam.  Bracket shelves directly
contact full-depth reinforced landing ribs; M5 fasteners locate the parts and resist lift rather than
depending on friction alone.

The diagonal brace is 12 mm wide by 9 mm deep.  Its lower endpoint extends into the long vertical member
and its upper endpoint terminates inside the shelf rather than at its edge.  A clipped 10 mm-radius node
surrounds each endpoint, increasing joint area and removing the nearly tangent connection seen in the
first slicer preview.  The nodes add roughly 22 g to the complete three-bracket keyboard configuration.
"""
    (DOC_DIR / "ENGINEERING_NOTES.md").write_text(engineering, encoding="utf-8")


def package_output() -> Path:
    final_archive = OUTPUT / "keyboard-mouse-platform-v4.zip"
    if final_archive.exists():
        final_archive.unlink()

    # Write the archive explicitly so a previously extracted package directory
    # cannot be pulled back into the new ZIP as a stale nested copy.
    excluded_tree = OUTPUT / "keyboard-mouse-platform-v4"
    with zipfile.ZipFile(final_archive, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for path in sorted(OUTPUT.rglob("*")):
            if not path.is_file() or path == final_archive or excluded_tree in path.parents:
                continue
            package.write(path, path.relative_to(OUTPUT))

    with zipfile.ZipFile(final_archive) as package:
        if package.testzip() is not None:
            raise RuntimeError("Generated ZIP failed CRC validation")
        if any(name.endswith("keyboard-mouse-platform-v4.zip") for name in package.namelist()):
            raise RuntimeError("Generated ZIP incorrectly contains itself")
    return final_archive


def main() -> int:
    make_dirs()
    print("Building split keyboard and mouse platform solids...")
    parts = build_parts(P)
    print("Exporting component STEP/STL files...")
    files = export_parts(parts, P)
    print("Exporting keyboard-only and full assemblies...")
    files.update(export_assemblies(parts, P))
    print("Rendering inspection views...")
    renders = render_all(parts, P)
    print("Re-importing and validating geometry...")
    report = validate(parts, files, P)
    (REPORT_DIR / "validation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (REPORT_DIR / "parameters.json").write_text(json.dumps(asdict(P), indent=2), encoding="utf-8")
    write_docs(P)
    shutil.copy2(ROOT / "keyboard_mouse_platform.py", OUTPUT / "keyboard_mouse_platform.py")
    shutil.copy2(ROOT / "drawer_organizer.py", OUTPUT / "drawer_organizer_dependency.py")
    shutil.copy2(ROOT / "requirements.txt", OUTPUT / "requirements.txt")
    shutil.copy2(ROOT / "README.md", OUTPUT / "PROJECT_README.md")
    archive = package_output()
    print(json.dumps({
        "validation": report["status"], "output": str(OUTPUT),
        "archive": str(archive), "renders": [str(path) for path in renders],
    }, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
