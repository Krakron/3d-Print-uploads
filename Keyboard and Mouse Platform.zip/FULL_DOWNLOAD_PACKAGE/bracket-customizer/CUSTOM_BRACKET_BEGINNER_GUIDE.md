# Custom Drawer Bracket Beginner Guide

This folder changes only the drawer-hook fit for **Drawer-Mounted Keyboard and Mouse Platform - Reinforced Modular Version**. It does not
resize the tray, radio cradle, keyboard deck, mouse wing, bottle well, storage
areas, or bolt locations.

## Before you begin

1. Measure the drawer front at the exact mounting location with calipers.
2. Keep the validated default files elsewhere in this package; this tool never
   replaces them.
3. Supported drawer-front thickness is 15.0 to 30.0 mm.
4. The default is 20.85 mm plus 0.65 mm extra,
   producing a 21.50 mm hook opening before optional padding.

## One-time setup

Double-click `SETUP_CUSTOMIZER_ONCE.cmd`. It explains that internet access is
needed and waits for you to type YES before downloading anything. The setup is
local to this folder.

## Change the measurement

Open `drawer-settings.json` in Notepad. Change only ordinary decimal numbers:

- `drawer_front_thickness_mm`: your measured board/trim thickness.
- `extra_fit_clearance_mm`: ease for printer tolerance and removal.
- `compressed_padding_total_mm`: total thickness occupied by compressed pads
  inside the hook.

The opening equals all three values added together. Do not use text, units,
commas, `NaN`, or negative numbers.

## Build and test

Double-click `BUILD_CUSTOM_BRACKETS.cmd`. Every run creates a new timestamped
folder beneath `generated-custom-brackets`; the validated defaults stay intact.
Print the drawer-fit coupon first. It should slide on without forcing the wood,
metal trim, or laminate. Only after the coupon passes should you print the full
bracket or adapter. Gradually load-test the assembled product over a soft area.

CAD validation cannot prove the condition of your drawer, slides, printed layer
bonding, heat-set inserts, nuts, or screws. Stop using any part that cracks,
creeps, loosens, or marks the furniture.
