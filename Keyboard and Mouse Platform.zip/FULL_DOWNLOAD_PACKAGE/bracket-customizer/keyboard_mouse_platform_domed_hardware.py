"""Separate v5 hardware revision for domed M5 screws and heat-set inserts.

This file intentionally leaves keyboard_mouse_platform.py and its v4 exports
unchanged.  It reuses the proven platform envelope, hook fit, reinforced brace,
and assembly locations, then replaces only the fastener interfaces.
"""

from __future__ import annotations

import json
import shutil
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import cadquery as cq
from cadquery import exporters

import drawer_organizer as geometry
import keyboard_mouse_platform as v4


@dataclass(frozen=True)
class DomedHardwareParameters(v4.PlatformParameters):
    # Generous pocket for an M5 button/pan/domed head.  Verify with the coupon.
    bolt_head_diameter: float = 12.5
    bolt_head_recess: float = 4.6

    # Blind heat-set seat in each bracket.  The normal 8 mm shelf receives a
    # local 4 mm underside boss, leaving a 4 mm physical stop below the pilot.
    insert_boss_diameter: float = 18.0
    insert_boss_drop: float = 4.0
    insert_pilot_diameter: float = 4.8
    insert_pilot_depth: float = 8.0
    insert_leadin_diameter: float = 6.2
    insert_leadin_depth: float = 1.0

    # Three alternate pilot sizes are included on the inexpensive test coupon.
    coupon_insert_pilots: Tuple[float, float, float] = (4.4, 4.8, 5.2)


P = DomedHardwareParameters()
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output" / "v5-domed-hardware"
STL_DIR = OUTPUT / "stl"
STEP_DIR = OUTPUT / "step"
RENDER_DIR = OUTPUT / "renders"
REPORT_DIR = OUTPUT / "reports"
DOC_DIR = OUTPUT / "docs"


def configure_v4_output_helpers() -> None:
    """Point reused rendering/validation helpers at this revision's folders."""
    v4.OUTPUT = OUTPUT
    v4.STL_DIR = STL_DIR
    v4.STEP_DIR = STEP_DIR
    v4.RENDER_DIR = RENDER_DIR
    v4.REPORT_DIR = REPORT_DIR
    v4.DOC_DIR = DOC_DIR


def make_dirs() -> None:
    for folder in (STL_DIR, STEP_DIR, RENDER_DIR, REPORT_DIR, DOC_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def slot_head_recess_length(p: DomedHardwareParameters = P) -> float:
    """Keep the same bolt-centre travel after widening the capsule recess."""
    through_d = p.bolt_nominal + p.bolt_clearance
    return p.slot_length - through_d + p.bolt_head_diameter


def add_domed_slot_recess(
    shape: cq.Workplane, x: float, y: float, p: DomedHardwareParameters = P,
) -> cq.Workplane:
    top_z = p.platform_base_z + p.platform_base_thickness
    cutter = geometry.horizontal_slot_cutter(
        x, y, top_z - p.bolt_head_recess, p.bolt_head_recess + 1.0,
        slot_head_recess_length(p), p.bolt_head_diameter,
    )
    return shape.cut(cutter)


def make_keyboard_half(side: str, p: DomedHardwareParameters = P) -> cq.Workplane:
    """V4 keyboard half plus recessed tracks above every bracket slot."""
    deck = v4.make_keyboard_half(side, p)
    half_w = p.keyboard_platform_width / 2
    x_min, x_max = ((-half_w, 0.0) if side == "left" else (0.0, half_w))
    for bracket_x in p.keyboard_bracket_x:
        if x_min < bracket_x < x_max:
            for bolt_y in p.keyboard_bolt_y:
                deck = add_domed_slot_recess(deck, bracket_x, bolt_y, p)
    return deck.clean()


def make_mouse_wing(p: DomedHardwareParameters = P) -> cq.Workplane:
    """V4 mouse wing with a recessed head track over both bracket slots."""
    wing = v4.make_mouse_wing(p)
    for bolt_y in p.mouse_bolt_y:
        wing = add_domed_slot_recess(wing, p.mouse_bracket_x, bolt_y, p)
    return wing.clean()


def add_blind_insert_seat(
    bracket: cq.Workplane, y: float, p: DomedHardwareParameters = P,
) -> cq.Workplane:
    """Fill the old through/nut pocket and cut a blind heat-set pilot."""
    shelf_top = p.platform_base_z - p.rib_height
    shelf_bottom = shelf_top - p.shelf_thickness

    # This cylinder both replaces the old cut-through fastener volume and adds
    # a local underside boss.  The shelf top and deck contact plane do not move.
    boss = v4.vertical_cylinder(
        0.0, y, shelf_bottom - p.insert_boss_drop,
        p.insert_boss_diameter, p.shelf_thickness + p.insert_boss_drop,
    )
    bracket = bracket.union(boss)

    # A small blind pilot tells the insert where to start while preserving a
    # substantial PETG stop underneath.  The shallow wide lead-in centres it.
    pilot = v4.vertical_cylinder(
        0.0, y, shelf_top - p.insert_pilot_depth,
        p.insert_pilot_diameter, p.insert_pilot_depth + 0.5,
    )
    leadin = v4.vertical_cylinder(
        0.0, y, shelf_top - p.insert_leadin_depth,
        p.insert_leadin_diameter, p.insert_leadin_depth + 0.5,
    )
    return bracket.cut(pilot).cut(leadin)


def make_insert_bracket(kind: str, p: DomedHardwareParameters = P) -> cq.Workplane:
    """Reinforced v4 bracket with blind heat-set seats instead of nut pockets."""
    bracket = v4.make_bracket(kind, p)
    bolt_positions = p.keyboard_bolt_y if kind == "keyboard" else p.mouse_bolt_y
    for y in bolt_positions:
        bracket = add_blind_insert_seat(bracket, y, p)
    return bracket.clean()


def make_hardware_fit_coupon(p: DomedHardwareParameters = P) -> cq.Workplane:
    """Cheap coupon: domed-head pocket at left, three insert pilots to right."""
    width = 24.0
    total_thickness = p.shelf_thickness + p.insert_boss_drop
    feature_x = (-32.0, -10.0, 12.0, 34.0)
    coupon = geometry.box_xyz(
        feature_x[-1] - feature_x[0], 5.0, 4.0,
        x_center=(feature_x[0] + feature_x[-1]) / 2,
        y_min=(width - 5.0) / 2, z_min=0.0,
    )
    for x in feature_x:
        coupon = coupon.union(v4.vertical_cylinder(
            x, width / 2, 0.0, p.insert_boss_diameter, total_thickness,
        ))

    # Left feature duplicates the deck through-hole and domed-head recess.
    x_head = -32.0
    coupon = coupon.cut(v4.vertical_cylinder(
        x_head, width / 2, -1.0,
        p.bolt_nominal + p.bolt_clearance, total_thickness + 2.0,
    ))
    coupon = coupon.cut(v4.vertical_cylinder(
        x_head, width / 2, total_thickness - p.bolt_head_recess,
        p.bolt_head_diameter, p.bolt_head_recess + 1.0,
    ))

    # Left-to-right: 4.4, 4.8, and 5.2 mm blind insert pilots.
    for x, diameter in zip(feature_x[1:], p.coupon_insert_pilots):
        coupon = coupon.cut(v4.vertical_cylinder(
            x, width / 2, total_thickness - p.insert_pilot_depth,
            diameter, p.insert_pilot_depth + 0.5,
        ))
        coupon = coupon.cut(v4.vertical_cylinder(
            x, width / 2, total_thickness - p.insert_leadin_depth,
            p.insert_leadin_diameter, p.insert_leadin_depth + 0.5,
        ))
    return coupon.clean()


def build_parts(p: DomedHardwareParameters = P) -> Dict[str, cq.Workplane]:
    return {
        "keyboard_left": make_keyboard_half("left", p),
        "keyboard_right": make_keyboard_half("right", p),
        "mouse_wing": make_mouse_wing(p),
        "joiner": v4.make_joiner(p),
        "keyboard_bracket": make_insert_bracket("keyboard", p),
        "mouse_bracket": make_insert_bracket("mouse", p),
        "hook_fit_test": v4.make_hook_fit_test(p),
        "hardware_fit_coupon": make_hardware_fit_coupon(p),
    }


def export_parts(
    parts: Dict[str, cq.Workplane], p: DomedHardwareParameters = P,
) -> Dict[str, Path]:
    step_names = {
        "keyboard_left": "keyboard_left_domed_head_recess_v5.step",
        "keyboard_right": "keyboard_right_domed_head_recess_v5.step",
        "mouse_wing": "mouse_pad_wing_domed_head_recess_v5.step",
        "joiner": "compatible_underside_joiner_unchanged_geometry.step",
        "keyboard_bracket": "keyboard_bracket_blind_heatset_pilots_v5_print_3.step",
        "mouse_bracket": "mouse_bracket_blind_heatset_pilots_v5.step",
        "hook_fit_test": "compatible_hook_fit_test_21p5mm.step",
        "hardware_fit_coupon": "domed_head_and_heatset_fit_coupon_v5.step",
    }
    stl_specs = {
        "keyboard_left": ("keyboard_left_domed_head_recess_v5_top_face_down.stl", "top_face_down"),
        "keyboard_right": ("keyboard_right_domed_head_recess_v5_top_face_down.stl", "top_face_down"),
        "mouse_wing": ("mouse_pad_wing_domed_head_recess_v5_top_face_down.stl", "top_face_down"),
        "joiner": ("compatible_underside_joiner_unchanged_geometry_print_4.stl", "base"),
        "keyboard_bracket": ("keyboard_bracket_blind_heatset_pilots_v5_print_3_on_side.stl", "side"),
        "mouse_bracket": ("mouse_bracket_blind_heatset_pilots_v5_on_side.stl", "side"),
        "hook_fit_test": ("compatible_hook_fit_test_21p5mm_on_side.stl", "side"),
        "hardware_fit_coupon": ("PRINT_FIRST_domed_head_and_heatset_fit_coupon_v5.stl", "base"),
    }
    files: Dict[str, Path] = {}
    for key, filename in step_names.items():
        path = STEP_DIR / filename
        exporters.export(parts[key], str(path))
        files[f"step_{key}"] = path
    for key, (filename, orientation) in stl_specs.items():
        path = STL_DIR / filename
        exporters.export(
            v4.oriented(parts[key], orientation), str(path),
            tolerance=p.stl_linear_tolerance,
            angularTolerance=p.stl_angular_tolerance,
        )
        files[f"stl_{key}"] = path
    return files


def export_assemblies(
    parts: Dict[str, cq.Workplane], p: DomedHardwareParameters = P,
) -> Dict[str, Path]:
    keyboard_path = STEP_DIR / "keyboard_platform_domed_hardware_v5_complete.step"
    v4.make_keyboard_assembly(parts, p).save(str(keyboard_path), mode="default")
    full_path = STEP_DIR / "keyboard_mouse_platform_domed_hardware_v5_complete.step"
    v4.make_full_assembly(parts, p).save(str(full_path), mode="default")
    return {"step_assembly_keyboard": keyboard_path, "step_assembly_full": full_path}


def render_hardware_details(
    parts: Dict[str, cq.Workplane], p: DomedHardwareParameters = P,
) -> List[Path]:
    # Half-width section exposes the blind heat-set cavity and solid bottom stop.
    section_box = geometry.box_xyz(
        p.bracket_width / 2, p.mouse_shelf_front_y + 20.0, 190.0,
        x_center=-p.bracket_width / 4, y_min=-5.0, z_min=-180.0,
    )
    bracket_section = parts["mouse_bracket"].intersect(section_box)

    # Isolate a mouse-wing patch around one recessed adjustable slot.
    patch_box = geometry.box_xyz(
        54.0, 58.0, 18.0, x_center=p.mouse_bracket_x,
        y_min=p.mouse_bolt_y[0] - 29.0, z_min=p.platform_base_z - p.rib_height - 1.0,
    )
    slot_patch = parts["mouse_wing"].intersect(patch_box)

    return [
        v4.render_scene(
            "blind_heatset_bracket_section_v5.png",
            [(bracket_section.val(), "#245f91", 1.0)],
            elev=0, azim=0,
            bounds=((-14, 2), (7, 34), (-30, -12)),
            title="V5 close section — blind insert pilot and 4 mm solid bottom stop",
        ),
        v4.render_scene(
            "domed_head_recessed_slot_detail_v5.png",
            [(slot_patch.val(), "#3b78a8", 1.0)],
            elev=84, azim=-90,
            bounds=((p.mouse_bracket_x - 32, p.mouse_bracket_x + 32),
                    (p.mouse_bolt_y[0] - 34, p.mouse_bolt_y[0] + 34),
                    (p.platform_base_z - p.rib_height - 2, p.platform_base_z + 5)),
            title="V5 platform detail — recessed head track around adjustable slot",
        ),
        v4.render_scene(
            "hardware_fit_coupon_v5.png",
            [(parts["hardware_fit_coupon"].val(), "#497fa6", 1.0)],
            elev=32, azim=-58,
            bounds=((-50, 50), (-4, 30), (-2, 16)),
            title="Print first — domed-head pocket plus 4.4 / 4.8 / 5.2 mm insert pilots",
        ),
    ]


def add_hardware_validation(
    report: Dict, p: DomedHardwareParameters = P,
) -> None:
    total_local_thickness = p.shelf_thickness + p.insert_boss_drop
    insert_stop = total_local_thickness - p.insert_pilot_depth
    landing_thickness = p.platform_base_thickness + p.rib_height
    recess_floor = landing_thickness - p.bolt_head_recess
    report["domed_hardware_checks"] = {
        "domed_head_recess_diameter_mm": p.bolt_head_diameter,
        "domed_head_recess_depth_mm": p.bolt_head_recess,
        "adjustable_head_track_total_length_mm": round(slot_head_recess_length(p), 3),
        "remaining_material_below_head_recess_mm": round(recess_floor, 3),
        "bracket_local_insert_seat_thickness_mm": total_local_thickness,
        "selected_blind_insert_pilot_diameter_mm": p.insert_pilot_diameter,
        "blind_insert_pilot_depth_mm": p.insert_pilot_depth,
        "solid_bottom_stop_below_insert_pilot_mm": round(insert_stop, 3),
        "coupon_pilot_diameters_left_to_right_mm": list(p.coupon_insert_pilots),
        "v4_files_modified": False,
    }
    if recess_floor < 3.0 or insert_stop < 3.0:
        report["status"] = "FAIL"
        report["warnings"].append("Fastener recess leaves less than 3 mm of backing material.")


def write_docs(p: DomedHardwareParameters = P) -> None:
    instructions = f"""# V5 domed-hardware keyboard and mouse platform

This is a separate replacement-part revision.  The existing v4 source and exported files were not
rewritten.  The v5 parts preserve the same deck envelopes, seams, hook clearance, bracket locations,
and reinforced diagonal braces.

## What changed

- Every adjustable bracket slot now has a {p.bolt_head_diameter:.1f} mm wide by
  {p.bolt_head_recess:.1f} mm deep recessed head track.
- Every round seam fastener recess uses the same larger/deeper domed-head pocket.
- The bracket nut pockets and through-holes are replaced by blind heat-set-insert seats.
- Each insert location has a {p.insert_boss_diameter:.0f} mm local boss, making the plastic
  {p.shelf_thickness + p.insert_boss_drop:.0f} mm thick only near the insert rather than thickening
  the entire bracket shelf.
- The production insert pilot is {p.insert_pilot_diameter:.1f} mm diameter and
  {p.insert_pilot_depth:.1f} mm deep with a {p.insert_leadin_diameter:.1f} mm shallow lead-in.
  A {p.shelf_thickness + p.insert_boss_drop - p.insert_pilot_depth:.1f} mm solid PETG stop remains
  below it, so the insert cannot simply fall through.

## Print the coupon first

Print `PRINT_FIRST_domed_head_and_heatset_fit_coupon_v5.stl` before any large part.  The left feature
checks the domed screw head.  The three blind insert pilots are, from left to right:
{p.coupon_insert_pilots[0]:.1f} mm, {p.coupon_insert_pilots[1]:.1f} mm, and
{p.coupon_insert_pilots[2]:.1f} mm.  The full parts use {p.insert_pilot_diameter:.1f} mm.

Because the screw head and heat-set insert were not measured with calipers, the selected dimensions
are deliberately generous estimates based on the photographs and M5 hardware.  Do not commit to the
large prints until the coupon confirms both fits.

## Heat-set installation

Install each insert from the flat top surface of the detached bracket, before attaching the platform.
Use the shallow wide lead-in to start it square.  Heat gradually and stop when the insert is flush with
the bracket shelf; do not try to drive it to the bottom of the blind pilot.  Let PETG cool completely
before installing a screw.  If the 4.8 mm coupon pilot bulges or takes excessive force, use the 5.2 mm
result and edit `insert_pilot_diameter` before regenerating.

## Which parts must be reprinted

- To add the mouse surface: print the v5 mouse-pad wing and v5 mouse bracket.  Reuse two existing seam
  joiners if they are sound.
- To make the keyboard surface compatible with the domed screws: print the v5 left and right halves.
- For blind insert retention on the keyboard supports: print three v5 keyboard brackets.
- Existing v4 parts may stay in service if you later replace the domed screws with genuinely flush
  heads and their insert locations remain undamaged.

## Suggested PETG settings

- 0.4 mm nozzle; 0.20 mm layers.
- Five walls on brackets, four walls on platform pieces.
- Six top/bottom layers.
- 35–45% gyroid or cubic infill for brackets; 20–25% for platform pieces.
- Use the supplied STL orientations.  Keep supports off unless your slicer finds a small local need.
- Tighten only until secure.  Heat-set inserts can spin if overtightened.
"""
    (DOC_DIR / "PRINT_AND_ASSEMBLY_V5.md").write_text(instructions, encoding="utf-8")

    notes = f"""# Engineering notes — v5 domed hardware

The loaded geometry and overall load screen remain the same as v4.  This revision changes fastener
interfaces only.  The adjustable head recess keeps the original bolt-centre travel while widening the
slot around the moving head.  The {p.platform_base_thickness + p.rib_height:.1f} mm landing thickness
retains {p.platform_base_thickness + p.rib_height - p.bolt_head_recess:.1f} mm beneath the head recess.

Each bracket insert is surrounded by an {p.insert_boss_diameter:.0f} mm boss and has a blind bottom.
This removes the direct fall-through path visible in the photographs.  Heat-set insertion temperature,
actual insert outside diameter, and screw-head geometry still require the inexpensive physical coupon;
the CAD validation is not a substitute for that fit test.
"""
    (DOC_DIR / "ENGINEERING_NOTES_V5.md").write_text(notes, encoding="utf-8")


def package_output() -> Path:
    archive_path = OUTPUT / "keyboard-mouse-platform-v5-domed-hardware.zip"
    if archive_path.exists():
        archive_path.unlink()
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for path in sorted(OUTPUT.rglob("*")):
            if path.is_file() and path != archive_path:
                package.write(path, path.relative_to(OUTPUT))
    with zipfile.ZipFile(archive_path) as package:
        if package.testzip() is not None:
            raise RuntimeError("Generated v5 ZIP failed CRC validation")
        if any(name.endswith(".zip") for name in package.namelist()):
            raise RuntimeError("Generated v5 ZIP incorrectly contains another ZIP")
    return archive_path


def main() -> int:
    configure_v4_output_helpers()
    make_dirs()
    print("Building separate v5 domed-hardware solids...")
    parts = build_parts(P)
    print("Exporting v5 STEP and STL components...")
    files = export_parts(parts, P)
    files.update(export_assemblies(parts, P))
    print("Rendering assembly and hardware details...")
    renders = v4.render_all(parts, P)
    renders.extend(render_hardware_details(parts, P))
    print("Re-importing and validating v5 geometry...")
    report = v4.validate(parts, files, P)
    add_hardware_validation(report, P)
    (REPORT_DIR / "validation_report_v5.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8",
    )
    (REPORT_DIR / "parameters_v5.json").write_text(
        json.dumps(asdict(P), indent=2), encoding="utf-8",
    )
    write_docs(P)
    shutil.copy2(__file__, OUTPUT / Path(__file__).name)
    shutil.copy2(ROOT / "keyboard_mouse_platform.py", OUTPUT / "v4_geometry_dependency_unchanged.py")
    shutil.copy2(ROOT / "drawer_organizer.py", OUTPUT / "drawer_organizer_dependency.py")
    shutil.copy2(ROOT / "requirements.txt", OUTPUT / "requirements.txt")
    archive = package_output()
    print(json.dumps({
        "validation": report["status"],
        "output": str(OUTPUT),
        "archive": str(archive),
        "renders": [str(path) for path in renders],
    }, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
