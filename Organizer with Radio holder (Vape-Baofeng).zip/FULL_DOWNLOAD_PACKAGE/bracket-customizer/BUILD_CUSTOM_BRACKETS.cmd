@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo The customizer is not set up yet.
  echo Run SETUP_CUSTOMIZER_ONCE.cmd first and read CUSTOM_BRACKET_BEGINNER_GUIDE.md.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" build_custom_brackets.py
if errorlevel 1 (
  echo Build stopped. Read the error above; no validated default files were replaced.
  pause
  exit /b 1
)
echo Build complete. Open generated-custom-brackets and print the coupon first.
pause
