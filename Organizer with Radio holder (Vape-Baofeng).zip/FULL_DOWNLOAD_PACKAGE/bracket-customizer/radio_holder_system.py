"""Parametric Baofeng radio holders for the drawer organizer project.

This v3 add-on creates:
  * a cheap radio-body fit collar;
  * a bottom-supported, removable radio cradle;
  * a fixed 21.5 mm drawer-front adapter for the proven dresser;
  * an adjustable two-screw edge clamp for other flat, sound panel edges; and
  * a revised organizer tray containing can, vape, radio, and catchall areas.

The factory spring belt clip is not a load-bearing part of this design.  The
radio rests on a printed floor and is laterally retained by the cradle walls.

Coordinate system in installed assemblies:
    X: along the drawer front
    Y: outward toward the bed (drawer outer face is Y=0)
    Z: upward (drawer top is Z=0)
"""

from __future__ import annotations

import json
import math
import shutil
import zipfile
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import cadquery as cq
from cadquery import exporters, importers

import drawer_organizer as v2


@dataclass(frozen=True)
class RadioParameters:
    # User-photo measurements.  Height is body only; antenna is not constrained.
    radio_measured_max_width: float = 62.07
    radio_measured_lower_width: float = 58.01
    radio_measured_depth: float = 40.37
    radio_measured_body_height: float = 157.73

    # Shared fit used by every radio pocket.
    radio_internal_width: float = 64.0
    radio_internal_depth: float = 43.5
    radio_inner_radius: float = 3.5
    radio_wall: float = 4.5
    radio_floor: float = 6.5
    radio_capture_height: float = 52.0
    radio_front_rail_height: float = 18.0
    radio_fit_test_height: float = 12.0
    radio_fit_test_wall: float = 3.0
    radio_pad_thickness: float = 1.5

    # Two vertical M5 fasteners join the cradle to a fully supporting shelf.
    cradle_bolt_nominal: float = 5.0
    cradle_bolt_clearance: float = 0.55
    cradle_bolt_x: float = 25.0
    cradle_bolt_y: float = 13.0
    cradle_head_diameter: float = 9.2
    cradle_head_recess: float = 3.5
    cradle_nut_across_flats: float = 8.2
    cradle_nut_thickness: float = 4.2

    # Shared adapter dimensions.
    adapter_width: float = 82.0
    adapter_plate_thickness: float = 8.0
    adapter_plate_length: float = 135.0
    adapter_top_above_drawer: float = 8.0
    cradle_bottom_z: float = -88.0
    shelf_thickness: float = 6.0
    shelf_front_y: float = 64.0
    gusset_width: float = 8.0
    pad_recess: float = 0.8

    # Drawer-specific inverted-U adapter.  Clearance matches the proven v1/v2.
    drawer_front_thickness: float = 20.85
    drawer_hook_clearance: float = 21.50
    drawer_hook_wall: float = 6.0
    drawer_hook_top: float = 8.0
    drawer_inner_leg_length: float = 32.0

    # Adjustable flat-edge clamp, using two ordinary fully threaded M8 bolts.
    adjustable_min_panel: float = 5.0
    adjustable_max_panel: float = 45.0
    adjustable_bridge_reach: float = 65.0
    adjustable_inner_plate_thickness: float = 10.0
    adjustable_inner_plate_length: float = 58.0
    clamp_bolt_nominal: float = 8.0
    clamp_bolt_clearance: float = 0.6
    clamp_bolt_x: float = 24.0
    clamp_bolt_z: float = -30.0
    clamp_nut_across_flats: float = 13.2
    clamp_nut_thickness: float = 6.8
    clamp_pad_diameter: float = 22.0
    clamp_pad_thickness: float = 5.0

    # V3 organizer layout.  Can position and mounting pattern remain unchanged.
    tray_vape_center_x: float = 7.0
    tray_radio_center_x: float = 65.0
    tray_radio_center_y: float = 49.0

    # Mesh export.
    stl_linear_tolerance: float = 0.08
    stl_angular_tolerance: float = 0.12


R = RadioParameters()
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output" / "v3-radio-system"
STL_DIR = OUTPUT / "stl"
STEP_DIR = OUTPUT / "step"
RENDER_DIR = OUTPUT / "renders"
REPORT_DIR = OUTPUT / "reports"
DOC_DIR = OUTPUT / "docs"


def make_dirs() -> None:
    for folder in (STL_DIR, STEP_DIR, RENDER_DIR, REPORT_DIR, DOC_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def rounded_ring(
    inner_w: float,
    inner_d: float,
    inner_r: float,
    wall: float,
    height: float,
    *,
    x_center: float = 0.0,
    y_center: float = 0.0,
    z_min: float = 0.0,
) -> cq.Workplane:
    outer = v2.rounded_rectangle_prism(
        inner_w + 2 * wall,
        inner_d + 2 * wall,
        inner_r + wall,
        height,
        x_center=x_center,
        y_center=y_center,
        z_min=z_min,
    )
    inner = v2.rounded_rectangle_prism(
        inner_w,
        inner_d,
        inner_r,
        height + 1.0,
        x_center=x_center,
        y_center=y_center,
        z_min=z_min - 0.5,
    )
    return outer.cut(inner).clean()


def vertical_cylinder(x: float, y: float, z_min: float, diameter: float, height: float) -> cq.Workplane:
    return (
        cq.Workplane("XY").center(x, y).circle(diameter / 2).extrude(height)
        .translate((0, 0, z_min))
    )


def y_axis_cylinder(x: float, y_start: float, z: float, diameter: float, length: float) -> cq.Workplane:
    # Positive extrusion from an XZ plane runs in -Y.
    return (
        cq.Workplane("XZ", origin=(0, y_start, 0)).center(x, z)
        .circle(diameter / 2).extrude(length)
    )


def y_axis_hex(x: float, y_start: float, z: float, across_flats: float, length: float) -> cq.Workplane:
    vertex_diameter = across_flats / math.cos(math.radians(30.0))
    return (
        cq.Workplane("XZ", origin=(0, y_start, 0)).center(x, z)
        .polygon(6, vertex_diameter).extrude(length)
    )


def make_radio_fit_test(r: RadioParameters = R) -> cq.Workplane:
    """Low-material collar for verifying the photographed body envelope."""
    return rounded_ring(
        r.radio_internal_width,
        r.radio_internal_depth,
        r.radio_inner_radius,
        r.radio_fit_test_wall,
        r.radio_fit_test_height,
    )


def make_radio_pad(r: RadioParameters = R) -> cq.Workplane:
    """Optional TPU floor pad sized slightly below the cavity walls."""
    return v2.rounded_rectangle_prism(
        r.radio_internal_width - 1.2,
        r.radio_internal_depth - 1.2,
        max(1.0, r.radio_inner_radius - 0.6),
        r.radio_pad_thickness,
    )


def make_radio_cradle(r: RadioParameters = R) -> cq.Workplane:
    """Bottom-supported cradle independent of the weak factory belt clip."""
    outer_w = r.radio_internal_width + 2 * r.radio_wall
    cavity_y0 = r.adapter_plate_thickness
    cavity_y1 = cavity_y0 + r.radio_internal_depth
    outer_y1 = cavity_y1 + r.radio_wall

    # Thick floor carries the full device weight and permits recessed bolt heads.
    floor = v2.rounded_rectangle_prism(
        outer_w,
        outer_y1,
        r.radio_inner_radius + r.radio_wall,
        r.radio_floor,
        y_center=outer_y1 / 2,
    )
    back = v2.box_xyz(
        outer_w,
        r.adapter_plate_thickness,
        r.radio_capture_height + r.radio_floor,
        y_min=0.0,
        z_min=0.0,
    )
    left = v2.box_xyz(
        r.radio_wall,
        r.radio_internal_depth + r.radio_wall,
        r.radio_capture_height,
        x_center=-outer_w / 2 + r.radio_wall / 2,
        y_min=cavity_y0,
        z_min=r.radio_floor,
    )
    right = v2.box_xyz(
        r.radio_wall,
        r.radio_internal_depth + r.radio_wall,
        r.radio_capture_height,
        x_center=outer_w / 2 - r.radio_wall / 2,
        y_min=cavity_y0,
        z_min=r.radio_floor,
    )
    # Low front rail prevents kick-out while leaving buttons and grip accessible.
    front = v2.box_xyz(
        outer_w,
        r.radio_wall,
        r.radio_front_rail_height,
        y_min=cavity_y1,
        z_min=r.radio_floor,
    )
    cradle = floor.union(back).union(left).union(right).union(front)

    bolt_d = r.cradle_bolt_nominal + r.cradle_bolt_clearance
    for x in (-r.cradle_bolt_x, r.cradle_bolt_x):
        cradle = cradle.cut(vertical_cylinder(x, r.cradle_bolt_y, -1.0, bolt_d, r.radio_floor + 2.0))
        cradle = cradle.cut(vertical_cylinder(
            x,
            r.cradle_bolt_y,
            r.radio_floor - r.cradle_head_recess,
            r.cradle_head_diameter,
            r.cradle_head_recess + 1.0,
        ))
    try:
        cradle = cradle.edges(">Z").chamfer(0.8)
    except Exception:
        pass
    return cradle.clean()


def make_common_adapter_body(r: RadioParameters = R) -> cq.Workplane:
    """Outside plate, cradle shelf, gussets, and captured M5 nuts."""
    y0 = r.adapter_plate_thickness
    shelf_z0 = r.cradle_bottom_z - r.shelf_thickness
    plate = v2.box_xyz(
        r.adapter_width,
        r.adapter_plate_thickness,
        r.adapter_plate_length + r.adapter_top_above_drawer,
        y_min=0.0,
        z_min=-r.adapter_plate_length,
    )
    shelf = v2.box_xyz(
        r.adapter_width,
        r.shelf_front_y - y0,
        r.shelf_thickness,
        y_min=y0,
        z_min=shelf_z0,
    )
    body = plate.union(shelf)

    # Twin YZ triangular ribs spread the shelf moment into the long plate.
    for x in (-26.0, 26.0):
        rib = (
            cq.Workplane("YZ")
            .moveTo(y0, shelf_z0)
            .lineTo(r.shelf_front_y, shelf_z0)
            .lineTo(y0, -r.adapter_plate_length + 1.0)
            .close()
            .extrude(r.gusset_width)
            .translate((x - r.gusset_width / 2, 0, 0))
        )
        body = body.union(rib)

    bolt_d = r.cradle_bolt_nominal + r.cradle_bolt_clearance
    nut_vertex_d = r.cradle_nut_across_flats / math.cos(math.radians(30.0))
    global_bolt_y = y0 + r.cradle_bolt_y
    for x in (-r.cradle_bolt_x, r.cradle_bolt_x):
        body = body.cut(vertical_cylinder(x, global_bolt_y, shelf_z0 - 1.0, bolt_d, r.shelf_thickness + 2.0))
        pocket = (
            cq.Workplane("XY").center(x, global_bolt_y).polygon(6, nut_vertex_d)
            .extrude(r.cradle_nut_thickness + 0.35)
            .translate((0, 0, shelf_z0 - 0.01))
        )
        body = body.cut(pocket)

    # Flush protective-pad recess on the drawer/panel contact face.
    body = body.cut(v2.box_xyz(
        r.adapter_width - 8.0,
        r.pad_recess,
        78.0,
        y_min=-0.01,
        z_min=-126.0,
    ))
    return body.clean()


def make_drawer_adapter(r: RadioParameters = R) -> cq.Workplane:
    """Fixed inverted-U adapter for the confirmed 20.85 mm drawer front."""
    body = make_common_adapter_body(r)
    inner_y0 = -(r.drawer_hook_clearance + r.drawer_hook_wall)
    cap = v2.box_xyz(
        r.adapter_width,
        r.drawer_hook_clearance + r.drawer_hook_wall + r.adapter_plate_thickness,
        r.drawer_hook_top,
        y_min=inner_y0,
        z_min=0.0,
    )
    inner_leg = v2.box_xyz(
        r.adapter_width,
        r.drawer_hook_wall,
        r.drawer_inner_leg_length + r.drawer_hook_top,
        y_min=inner_y0,
        z_min=-r.drawer_inner_leg_length,
    )
    adapter = body.union(cap).union(inner_leg)

    # Recesses accept thin protective pads without reducing the proven clearance.
    adapter = adapter.cut(v2.box_xyz(
        r.adapter_width - 8.0,
        r.pad_recess + 0.01,
        22.0,
        y_min=-r.drawer_hook_clearance - r.pad_recess,
        z_min=-27.0,
    ))
    adapter = adapter.cut(v2.box_xyz(
        r.adapter_width - 8.0,
        r.drawer_hook_clearance - 2.0,
        r.pad_recess + 0.01,
        y_min=-r.drawer_hook_clearance + 1.0,
        z_min=-0.01,
    ))
    return adapter.clean()


def make_adjustable_adapter(r: RadioParameters = R) -> cq.Workplane:
    """Two-screw clamp for flat panel edges from 5 to 45 mm nominal thickness."""
    body = make_common_adapter_body(r)
    inner_y0 = -r.adjustable_bridge_reach
    bridge = v2.box_xyz(
        r.adapter_width,
        r.adjustable_bridge_reach + r.adapter_plate_thickness,
        8.0,
        y_min=inner_y0,
        z_min=0.0,
    )
    inner_plate = v2.box_xyz(
        r.adapter_width,
        r.adjustable_inner_plate_thickness,
        r.adjustable_inner_plate_length + 8.0,
        y_min=inner_y0,
        z_min=-r.adjustable_inner_plate_length,
    )
    clamp = body.union(bridge).union(inner_plate)

    hole_d = r.clamp_bolt_nominal + r.clamp_bolt_clearance
    # From the inside face at Y=-65 toward the drawer at Y=0.
    for x in (-r.clamp_bolt_x, r.clamp_bolt_x):
        clamp = clamp.cut(y_axis_cylinder(
            x,
            inner_y0 + r.adjustable_inner_plate_thickness + 1.0,
            r.clamp_bolt_z,
            hole_d,
            r.adjustable_inner_plate_thickness + 2.0,
        ))
        clamp = clamp.cut(y_axis_hex(
            x,
            inner_y0 + r.clamp_nut_thickness,
            r.clamp_bolt_z,
            r.clamp_nut_across_flats,
            r.clamp_nut_thickness + 0.2,
        ))

    # Ribs strengthen both 90-degree clamp corners without blocking bolt access.
    for x in (-34.0, 34.0):
        inner_rib = (
            cq.Workplane("YZ")
            .moveTo(inner_y0, 0.0)
            .lineTo(inner_y0 + 20.0, 0.0)
            .lineTo(inner_y0, -24.0)
            .close().extrude(6.0).translate((x - 3.0, 0, 0))
        )
        clamp = clamp.union(inner_rib)
    return clamp.clean()


def make_clamp_pad(r: RadioParameters = R) -> cq.Workplane:
    """Loose pressure puck for an M8 bolt tip; print two."""
    puck = cq.Workplane("XY").circle(r.clamp_pad_diameter / 2).extrude(r.clamp_pad_thickness)
    dimple = (
        cq.Workplane("XY").circle((r.clamp_bolt_nominal + 0.5) / 2)
        .extrude(2.6).translate((0, 0, r.clamp_pad_thickness - 2.6))
    )
    return puck.cut(dimple).clean()


def make_tray_radio_wall(r: RadioParameters, p: v2.Parameters) -> cq.Workplane:
    """Radio sleeve for the tray with a high front access opening."""
    z_top = p.tray_bottom_z + p.tray_base_thickness
    wall = rounded_ring(
        r.radio_internal_width,
        r.radio_internal_depth,
        r.radio_inner_radius,
        r.radio_wall,
        r.radio_capture_height,
        x_center=r.tray_radio_center_x,
        y_center=r.tray_radio_center_y,
        z_min=z_top,
    )
    # Remove only the upper middle of the bed-facing wall; retain a low rail.
    front_y = r.tray_radio_center_y + r.radio_internal_depth / 2
    notch = v2.box_xyz(
        34.0,
        r.radio_wall + 2.0,
        r.radio_capture_height - r.radio_front_rail_height + 1.0,
        x_center=r.tray_radio_center_x,
        y_min=front_y - 0.2,
        z_min=z_top + r.radio_front_rail_height,
    )
    return wall.cut(notch).clean()


def make_v3_tray(r: RadioParameters = R) -> Tuple[cq.Workplane, v2.Parameters]:
    """Proven tray/mount envelope with a compact can-vape-radio layout."""
    p = replace(v2.P, vape_center_x=r.tray_vape_center_x)
    t = p.structural_wall_thickness
    z0 = p.tray_bottom_z
    z_top = z0 + p.tray_base_thickness
    y0 = p.tray_back_y
    outer_can_d = p.soda_holder_diameter + 2 * p.soda_holder_wall_thickness

    base = v2.box_xyz(p.tray_width, p.tray_depth, p.tray_base_thickness, y_min=y0, z_min=z0)
    wall_h = p.catchall_wall_height
    rear = v2.box_xyz(p.tray_width, t, wall_h, y_min=y0, z_min=z_top)
    front = v2.box_xyz(p.tray_width, t, wall_h, y_min=y0 + p.tray_depth - t, z_min=z_top)
    left = v2.box_xyz(t, p.tray_depth - 2 * t, wall_h,
                      x_center=-p.tray_width / 2 + t / 2, y_min=y0 + t, z_min=z_top)
    right = v2.box_xyz(t, p.tray_depth - 2 * t, wall_h,
                       x_center=p.tray_width / 2 - t / 2, y_min=y0 + t, z_min=z_top)

    can_outer = (
        cq.Workplane("XY").center(p.soda_center_x, p.soda_center_y)
        .circle(outer_can_d / 2).extrude(p.soda_holder_wall_height).translate((0, 0, z_top))
    )
    can_inner = (
        cq.Workplane("XY").center(p.soda_center_x, p.soda_center_y)
        .circle(p.soda_holder_diameter / 2).extrude(p.soda_holder_wall_height + 1.0)
        .translate((0, 0, z_top))
    )
    tray = (
        base.union(rear).union(front).union(left).union(right)
        .union(can_outer.cut(can_inner)).union(v2.make_vape_wall(p))
        .union(make_tray_radio_wall(r, p))
    )

    slot_d = p.bolt_nominal_diameter + p.bolt_clearance
    for bx in (-p.bracket_spacing / 2, p.bracket_spacing / 2):
        for by in (p.bolt_y_near, p.bolt_y_far):
            tray = tray.cut(v2.horizontal_slot_cutter(
                bx, by, z0 - 1.0, p.tray_base_thickness + 2.0,
                p.bolt_slot_length, slot_d,
            ))
    try:
        tray = tray.edges("|Z").fillet(min(p.fillet_radius, 3.0))
    except Exception:
        pass
    return tray.clean(), p


def make_v3_radio_pad(r: RadioParameters = R) -> cq.Workplane:
    return make_radio_pad(r)


def oriented(shape: cq.Workplane, mode: str) -> cq.Workplane:
    result = shape
    if mode == "side":
        result = result.rotate((0, 0, 0), (0, 1, 0), 90)
    bb = result.val().BoundingBox()
    return result.translate((0, 0, -bb.zmin))


def build_parts(r: RadioParameters = R) -> Tuple[Dict[str, cq.Workplane], v2.Parameters]:
    tray, tray_params = make_v3_tray(r)
    return {
        "radio_fit_test": make_radio_fit_test(r),
        "radio_cradle": make_radio_cradle(r),
        "radio_pad": make_radio_pad(r),
        "drawer_adapter": make_drawer_adapter(r),
        "adjustable_adapter": make_adjustable_adapter(r),
        "clamp_pad": make_clamp_pad(r),
        "tray_v3": tray,
        "tray_radio_pad": make_v3_radio_pad(r),
        # Re-export unchanged, field-tested v2 components so this package is standalone.
        "proven_tray_bracket": v2.make_mounting_bracket(tray_params),
        "proven_drawer_hook_fit_test": v2.make_fit_test(tray_params),
        "can_pad": v2.make_can_pad(tray_params),
        "vape_pad": v2.make_vape_pad(tray_params),
    }, tray_params


def export_parts(parts: Dict[str, cq.Workplane], r: RadioParameters = R) -> Dict[str, Path]:
    step_names = {
        "radio_fit_test": "radio_body_fit_test_64x43p5mm.step",
        "radio_cradle": "radio_cradle_bottom_supported.step",
        "radio_pad": "optional_radio_bottom_pad_tpu.step",
        "drawer_adapter": "radio_mount_drawer_adapter_21p5mm.step",
        "adjustable_adapter": "radio_mount_adjustable_edge_clamp_5_to_45mm.step",
        "clamp_pad": "adjustable_clamp_pressure_pad.step",
        "tray_v3": "organizer_tray_v3_can_vape_radio.step",
        "tray_radio_pad": "optional_tray_radio_pad_tpu.step",
        "proven_tray_bracket": "proven_organizer_mounting_bracket_unchanged.step",
        "proven_drawer_hook_fit_test": "proven_drawer_hook_fit_test_21p5mm.step",
        "can_pad": "optional_can_base_pad_tpu.step",
        "vape_pad": "optional_vape_bottom_pad_tpu.step",
    }
    stl_specs = {
        "radio_fit_test": ("radio_body_fit_test_64x43p5mm_print_flat.stl", "base"),
        "radio_cradle": ("radio_cradle_bottom_supported_print_upright.stl", "base"),
        "radio_pad": ("optional_radio_bottom_pad_tpu.stl", "base"),
        "drawer_adapter": ("radio_mount_drawer_adapter_21p5mm_print_on_side.stl", "side"),
        "adjustable_adapter": ("radio_mount_adjustable_edge_clamp_print_on_side.stl", "side"),
        "clamp_pad": ("adjustable_clamp_pressure_pad_print_2.stl", "base"),
        "tray_v3": ("organizer_tray_v3_can_vape_radio_print_flat.stl", "base"),
        "tray_radio_pad": ("optional_tray_radio_pad_tpu.stl", "base"),
        "proven_tray_bracket": ("proven_organizer_mounting_bracket_print_2_on_side.stl", "side"),
        "proven_drawer_hook_fit_test": ("proven_drawer_hook_fit_test_21p5mm_print_on_side.stl", "side"),
        "can_pad": ("optional_can_base_pad_tpu.stl", "base"),
        "vape_pad": ("optional_vape_bottom_pad_tpu.stl", "base"),
    }
    files: Dict[str, Path] = {}
    for key, name in step_names.items():
        path = STEP_DIR / name
        exporters.export(parts[key], str(path))
        files[f"step_{key}"] = path
    for key, (name, mode) in stl_specs.items():
        path = STL_DIR / name
        exporters.export(
            oriented(parts[key], mode), str(path),
            tolerance=r.stl_linear_tolerance,
            angularTolerance=r.stl_angular_tolerance,
        )
        files[f"stl_{key}"] = path
    return files


def add_cradle_assembly(
    assembly: cq.Assembly,
    adapter: cq.Workplane,
    adapter_name: str,
    r: RadioParameters = R,
) -> None:
    assembly.add(adapter, name=adapter_name, color=cq.Color(0.12, 0.29, 0.48))
    cradle_loc = cq.Location(cq.Vector(r.adapter_plate_thickness, 0, 0))
    # cq.Location vector order is X,Y,Z; use an explicit transform below instead.
    del cradle_loc
    assembly.add(
        make_radio_cradle(r), name="bottom_supported_radio_cradle",
        loc=cq.Location(cq.Vector(0, r.adapter_plate_thickness, r.cradle_bottom_z)),
        color=cq.Color(0.18, 0.43, 0.68),
    )


def clamp_hardware_reference(
    x: float,
    panel_thickness: float,
    r: RadioParameters = R,
) -> Tuple[cq.Workplane, cq.Workplane]:
    """Illustrative M8 screw and printed pressure pad for a given panel."""
    pad_outer_y = -panel_thickness
    pad_inner_y = pad_outer_y - r.clamp_pad_thickness
    screw_inner_y = -r.adjustable_bridge_reach - 5.0
    shank_len = pad_inner_y - screw_inner_y
    shank = y_axis_cylinder(
        x, pad_inner_y, r.clamp_bolt_z,
        r.clamp_bolt_nominal, shank_len,
    )
    head = y_axis_cylinder(x, screw_inner_y, r.clamp_bolt_z, 13.5, 6.0)
    bolt = shank.union(head)
    pad = make_clamp_pad(r).rotate((0, 0, 0), (1, 0, 0), 90).translate(
        (x, pad_outer_y, r.clamp_bolt_z)
    )
    return bolt, pad
    assembly.add(
        make_radio_pad(r), name="optional_TPU_floor_pad",
        loc=cq.Location(cq.Vector(
            0,
            r.adapter_plate_thickness + r.adapter_plate_thickness + r.radio_internal_depth / 2,
            r.cradle_bottom_z + r.radio_floor,
        )),
        color=cq.Color(0.10, 0.10, 0.10),
    )


def export_assemblies(parts: Dict[str, cq.Workplane], r: RadioParameters = R) -> Dict[str, Path]:
    outputs: Dict[str, Path] = {}
    fixed = cq.Assembly(name="drawer_specific_radio_mount")
    add_cradle_assembly(fixed, parts["drawer_adapter"], "drawer_adapter_21p5mm", r)
    fixed_path = STEP_DIR / "radio_mount_drawer_specific_complete_assembly.step"
    fixed.save(str(fixed_path), mode="default")
    outputs["step_assembly_drawer"] = fixed_path

    adjustable = cq.Assembly(name="adjustable_edge_clamp_radio_mount")
    add_cradle_assembly(adjustable, parts["adjustable_adapter"], "adjustable_adapter", r)
    for index, x in enumerate((-r.clamp_bolt_x, r.clamp_bolt_x), 1):
        bolt, pad = clamp_hardware_reference(x, r.drawer_front_thickness, r)
        adjustable.add(bolt, name=f"illustrative_M8_bolt_{index}", color=cq.Color(0.68, 0.70, 0.73))
        adjustable.add(pad, name=f"printed_pressure_pad_{index}", color=cq.Color(0.12, 0.12, 0.12))
    adjustable_path = STEP_DIR / "radio_mount_adjustable_complete_assembly.step"
    adjustable.save(str(adjustable_path), mode="default")
    outputs["step_assembly_adjustable"] = adjustable_path

    tray_assembly = cq.Assembly(name="organizer_v3_can_vape_radio")
    tray_assembly.add(parts["tray_v3"], name="tray_v3", color=cq.Color(0.16, 0.39, 0.65))
    bracket = parts["proven_tray_bracket"]
    for side, x in (("left", -v2.P.bracket_spacing / 2), ("right", v2.P.bracket_spacing / 2)):
        tray_assembly.add(bracket, name=f"proven_bracket_{side}",
                          loc=cq.Location(cq.Vector(x, 0, 0)), color=cq.Color(0.10, 0.25, 0.43))
    tray_path = STEP_DIR / "organizer_v3_can_vape_radio_complete_assembly.step"
    tray_assembly.save(str(tray_path), mode="default")
    outputs["step_assembly_tray"] = tray_path
    return outputs


def render_scene(
    filename: str,
    scene: Sequence[Tuple[cq.Shape, str, float]],
    *, elev: float, azim: float,
    bounds: Sequence[Tuple[float, float]],
    title: str,
) -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(10, 8), dpi=170)
    ax = fig.add_subplot(111, projection="3d", computed_zorder=False)
    for shape, color, alpha in scene:
        v2.add_shape_to_axis(ax, shape, color, alpha)
    v2.set_axes_equal(ax, bounds)
    ax.view_init(elev=elev, azim=azim)
    ax.set_axis_off()
    ax.set_title(title, pad=16)
    fig.patch.set_facecolor("#f5f4f0")
    ax.set_facecolor("#f5f4f0")
    plt.tight_layout()
    path = RENDER_DIR / filename
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def radio_reference(r: RadioParameters, y_center: float, z_bottom: float) -> cq.Shape:
    return v2.rounded_rectangle_prism(
        r.radio_measured_max_width,
        r.radio_measured_depth,
        3.0,
        r.radio_measured_body_height,
        y_center=y_center,
        z_min=z_bottom,
    ).val()


def render_all(parts: Dict[str, cq.Workplane], tray_p: v2.Parameters, r: RadioParameters = R) -> List[Path]:
    cradle = parts["radio_cradle"].translate((0, r.adapter_plate_thickness, r.cradle_bottom_z)).val()
    radio = radio_reference(
        r,
        r.adapter_plate_thickness + r.adapter_plate_thickness + r.radio_internal_depth / 2,
        r.cradle_bottom_z + r.radio_floor + r.radio_pad_thickness,
    )
    drawer_front = v2.box_xyz(150, r.drawer_front_thickness, 190,
                              y_min=-r.drawer_front_thickness, z_min=-182).val()
    fixed_scene = [
        (drawer_front, "#8a552f", 0.78),
        (parts["drawer_adapter"].val(), "#1f568d", 1.0),
        (cradle, "#327fbd", 1.0),
        (radio, "#22252a", 0.96),
    ]
    paths = [render_scene(
        "radio_mount_drawer_specific_installed.png", fixed_scene,
        elev=18, azim=-53, bounds=((-100, 100), (-70, 100), (-190, 115)),
        title="Drawer-specific radio mount — direct body support, 21.5 mm hook",
    )]

    panel_t = r.drawer_front_thickness
    generic_panel = v2.box_xyz(150, panel_t, 190, y_min=-panel_t, z_min=-182).val()
    adjustable_scene = [
        (generic_panel, "#8f785f", 0.62),
        (parts["adjustable_adapter"].val(), "#1f568d", 1.0),
        (cradle, "#327fbd", 1.0),
        (radio, "#22252a", 0.96),
    ]
    for x in (-r.clamp_bolt_x, r.clamp_bolt_x):
        bolt, pad = clamp_hardware_reference(x, panel_t, r)
        adjustable_scene.append((bolt.val(), "#b5b8bc", 1.0))
        adjustable_scene.append((pad.val(), "#242424", 1.0))
    paths.append(render_scene(
        "radio_mount_adjustable_on_20p85mm_panel.png", adjustable_scene,
        elev=17, azim=-50, bounds=((-100, 100), (-90, 100), (-190, 115)),
        title="Adjustable two-screw edge clamp — shown on a 20.85 mm panel",
    ))

    tray = parts["tray_v3"].val()
    left_b = parts["proven_tray_bracket"].translate((-tray_p.bracket_spacing / 2, 0, 0)).val()
    right_b = parts["proven_tray_bracket"].translate((tray_p.bracket_spacing / 2, 0, 0)).val()
    can = (
        cq.Workplane("XY").center(tray_p.soda_center_x, tray_p.soda_center_y)
        .circle(33).extrude(122).translate((0, 0, tray_p.tray_bottom_z + tray_p.tray_base_thickness))
        .val()
    )
    vape = v2.rounded_rectangle_prism(
        tray_p.vape_measured_width, tray_p.vape_measured_length, 4.0, 96.0,
        x_center=tray_p.vape_center_x, y_center=tray_p.vape_center_y,
        z_min=tray_p.tray_bottom_z + tray_p.tray_base_thickness,
    ).val()
    tray_radio = v2.rounded_rectangle_prism(
        r.radio_measured_max_width, r.radio_measured_depth, 3.0,
        r.radio_measured_body_height,
        x_center=r.tray_radio_center_x, y_center=r.tray_radio_center_y,
        z_min=tray_p.tray_bottom_z + tray_p.tray_base_thickness + r.radio_pad_thickness,
    ).val()
    tray_scene = [
        (tray, "#2d79bd", 1.0), (left_b, "#1c4f82", 1.0), (right_b, "#1c4f82", 1.0),
        (can, "#d64a3d", 0.96), (vape, "#4d405d", 0.96), (tray_radio, "#22252a", 0.96),
    ]
    paths.append(render_scene(
        "organizer_v3_can_vape_radio_isometric.png", tray_scene,
        elev=25, azim=-56, bounds=((-125, 125), (-45, 165), (-150, 190)),
        title="Organizer v3 — can, vape, direct radio pocket, and catchall",
    ))
    paths.append(render_scene(
        "organizer_v3_top_layout.png", tray_scene,
        elev=86, azim=-90, bounds=((-125, 125), (-20, 165), (-35, 180)),
        title="V3 top layout — radio and can kept close to the drawer",
    ))
    return paths


def validate(
    parts: Dict[str, cq.Workplane],
    files: Dict[str, Path],
    tray_p: v2.Parameters,
    r: RadioParameters = R,
) -> Dict:
    import trimesh

    report: Dict = {
        "status": "PASS",
        "radio_parameters_mm": asdict(r),
        "solid_checks": {}, "mesh_checks": {}, "step_reimport_checks": {},
        "fit_checks": {}, "interference_checks": {}, "warnings": [],
    }
    for name, wp in parts.items():
        shape = wp.val()
        bb = shape.BoundingBox()
        entry = {
            "valid": bool(shape.isValid()), "solid_count": len(shape.Solids()),
            "volume_mm3": round(shape.Volume(), 2),
            "bounding_box_mm": [round(bb.xlen, 3), round(bb.ylen, 3), round(bb.zlen, 3)],
        }
        report["solid_checks"][name] = entry
        if not entry["valid"] or entry["solid_count"] != 1 or entry["volume_mm3"] <= 0:
            report["status"] = "FAIL"

    for key, path in files.items():
        if key.startswith("stl_"):
            mesh = trimesh.load_mesh(path, process=True)
            entry = {
                "vertices": int(len(mesh.vertices)), "faces": int(len(mesh.faces)),
                "watertight": bool(mesh.is_watertight),
                "winding_consistent": bool(mesh.is_winding_consistent),
                "volume_mm3": round(abs(float(mesh.volume)), 2),
                "bounding_box_mm": [round(float(v), 3) for v in mesh.extents],
            }
            report["mesh_checks"][path.name] = entry
            if not entry["watertight"] or not entry["winding_consistent"] or entry["faces"] == 0:
                report["status"] = "FAIL"
        if key.startswith("step_"):
            imported = importers.importStep(str(path)).val()
            entry = {
                "valid": bool(imported.isValid()), "solid_count": len(imported.Solids()),
                "volume_mm3": round(imported.Volume(), 2),
            }
            report["step_reimport_checks"][path.name] = entry
            if not entry["valid"] or entry["solid_count"] < 1:
                report["status"] = "FAIL"

    report["fit_checks"] = {
        "radio_measured_max_width_mm": r.radio_measured_max_width,
        "radio_measured_depth_mm": r.radio_measured_depth,
        "holder_internal_width_mm": r.radio_internal_width,
        "holder_internal_depth_mm": r.radio_internal_depth,
        "total_width_clearance_mm": round(r.radio_internal_width - r.radio_measured_max_width, 3),
        "total_depth_clearance_mm": round(r.radio_internal_depth - r.radio_measured_depth, 3),
        "drawer_front_mm": r.drawer_front_thickness,
        "drawer_hook_clearance_mm": r.drawer_hook_clearance,
        "drawer_hook_slack_mm": round(r.drawer_hook_clearance - r.drawer_front_thickness, 3),
        "adjustable_nominal_panel_range_mm": [r.adjustable_min_panel, r.adjustable_max_panel],
        "tray_plan_mm": [tray_p.tray_width, tray_p.tray_depth],
    }
    if r.radio_internal_width <= r.radio_measured_max_width or r.radio_internal_depth <= r.radio_measured_depth:
        report["status"] = "FAIL"
        report["warnings"].append("Radio cavity is not larger than the photographed body measurements.")
    if r.drawer_hook_clearance <= r.drawer_front_thickness:
        report["status"] = "FAIL"
        report["warnings"].append("Drawer hook clearance is not larger than the confirmed drawer thickness.")

    # Cradle base must be fully supported by the adapter shelf, with only intended contact.
    cradle_installed = parts["radio_cradle"].translate((0, r.adapter_plate_thickness, r.cradle_bottom_z)).val()
    fixed_intersection = cradle_installed.intersect(parts["drawer_adapter"].val()).Volume()
    adjustable_intersection = cradle_installed.intersect(parts["adjustable_adapter"].val()).Volume()

    # Check radio pocket against all four tray slots and neighboring holder walls.
    radio_wall = make_tray_radio_wall(r, tray_p).val()
    vape_wall = v2.make_vape_wall(tray_p).val()
    holder_outer = tray_p.soda_holder_diameter + 2 * tray_p.soda_holder_wall_thickness
    z_top = tray_p.tray_bottom_z + tray_p.tray_base_thickness
    can_outer = (
        cq.Workplane("XY").center(tray_p.soda_center_x, tray_p.soda_center_y)
        .circle(holder_outer / 2).extrude(r.radio_capture_height).translate((0, 0, z_top))
    )
    can_inner = (
        cq.Workplane("XY").center(tray_p.soda_center_x, tray_p.soda_center_y)
        .circle(tray_p.soda_holder_diameter / 2).extrude(r.radio_capture_height + 1).translate((0, 0, z_top))
    )
    can_wall = can_outer.cut(can_inner).val()
    slot_intersection = 0.0
    for bx in (-tray_p.bracket_spacing / 2, tray_p.bracket_spacing / 2):
        for by in (tray_p.bolt_y_near, tray_p.bolt_y_far):
            slot_intersection += radio_wall.intersect(v2.horizontal_slot_cutter(
                bx, by, z_top - 1.0, 2.0, tray_p.bolt_slot_length,
                tray_p.bolt_nominal_diameter + tray_p.bolt_clearance,
            ).val()).Volume()
    radio_vape = radio_wall.intersect(vape_wall).Volume()
    vape_can = vape_wall.intersect(can_wall).Volume()
    report["interference_checks"] = {
        "installed_cradle_to_drawer_adapter_mm3": round(fixed_intersection, 6),
        "installed_cradle_to_adjustable_adapter_mm3": round(adjustable_intersection, 6),
        "tray_radio_wall_to_slots_mm3": round(slot_intersection, 6),
        "tray_radio_wall_to_vape_wall_mm3": round(radio_vape, 6),
        "tray_vape_wall_to_can_wall_mm3": round(vape_can, 6),
        "note": "Cradle/adapter should touch at shelf and rear faces but must not overlap in volume.",
    }
    if any(v > 0.001 for v in (fixed_intersection, adjustable_intersection, slot_intersection, radio_vape, vape_can)):
        report["status"] = "FAIL"
        report["warnings"].append("An unintended positive-volume component interference was detected.")

    # Engineering estimate only; actual radio mass and bump loads require a physical test.
    can_mass_kg = 0.40
    assumed_radio_mass_kg = 0.35
    misc_mass_kg = 0.20
    static_moment_nm = 9.81 * (
        can_mass_kg * tray_p.soda_center_y / 1000
        + assumed_radio_mass_kg * r.tray_radio_center_y / 1000
        + misc_mass_kg * 0.10
    )
    report["engineering_estimate"] = {
        "assumptions": {
            "full_can_kg": can_mass_kg,
            "radio_kg_unmeasured_estimate": assumed_radio_mass_kg,
            "miscellaneous_kg": misc_mass_kg,
            "miscellaneous_center_from_drawer_m": 0.10,
        },
        "tray_static_forward_moment_Nm": round(static_moment_nm, 3),
        "two_x_bump_screening_moment_Nm": round(2 * static_moment_nm, 3),
        "status": "screening calculation only; not a load rating",
    }
    return report


def write_docs(r: RadioParameters = R) -> None:
    instructions = f"""# Radio holder system v3 — print and assembly

## Print the fit test first

Print `radio_body_fit_test_64x43p5mm_print_flat.stl`.  Its opening is
{r.radio_internal_width:.1f} x {r.radio_internal_depth:.1f} mm.  Slide it over the widest usable
part of the radio body without forcing it.  The photos establish the maximum width and depth,
but not every corner radius or battery-case bulge.  Stop here and edit the two internal-size
parameters if the collar binds.

## Which mount to use

- The drawer-specific adapter preserves the already successful 21.5 mm hook clearance for the
  measured 20.85 mm dresser front.  It is the preferred part for this drawer.
- The adjustable adapter is for flat, structurally sound panel edges only.  It uses two screws
  so it resists yaw better than a single point.  Its nominal panel range is 5–45 mm; verify the
  available flat contact area before loading it.
- Both use the same removable cradle.  The radio rests on the floor and front rail; the weak
  factory spring belt clip is intentionally unused.

## Hardware

- Each standalone mount: 2 x M5 socket-head screws, 16–20 mm long; 2 x M5 hex nuts; washers as needed.
- Adjustable mount only: 2 x fully threaded M8 x 70 mm bolts, 2 x M8 hex nuts, and 2 printed pressure
  pads.  Add thin rubber/TPU to every wood-contact surface.  Do not tighten hard enough to crush,
  dent, or delaminate the furniture.
- V3 organizer tray: reuse the proven two brackets and four M5 fasteners from v1/v2.

## Print sets

- Tray upgrade only: print `organizer_tray_v3_can_vape_radio_print_flat.stl`; reuse the two proven
  organizer brackets.  The package also includes the bracket STL marked `print_2` if replacements
  are needed.
- Drawer-specific standalone radio mount: print one radio cradle and one 21.5 mm drawer adapter.
- Adjustable standalone radio mount: print one radio cradle, one adjustable adapter, and two
  pressure pads.  The pressure-pad STL contains one puck and is intentionally marked `print_2`.
- TPU pads are optional.  Do not print a rigid PETG pad thicker than specified because it can
  reduce the designed clearance.

## Assembly

1. Load the two M5 nuts into the hex pockets under the adapter shelf.
2. Set the cradle on the shelf with its rear wall against the long adapter plate.
3. Insert the M5 screws through the recessed holes in the cradle floor and tighten until snug.
   The shelf carries the weight; the screws locate the cradle and resist lift/sliding.
4. Cover the recessed screw heads with the optional TPU radio pad.
5. For the adjustable adapter, load the M8 nuts into the inner clamp plate, run both bolts evenly,
   place one pressure pad at each tip, and alternate tightening until the mount cannot rock by hand.

## PETG slicer starting point (0.4 mm nozzle)

- 0.20 mm layers (0.24 mm is acceptable for the fit coupon).
- 5 walls for the cradle/tray; 6 walls for either adapter.
- 6 top and 6 bottom layers.
- 35% gyroid/cubic infill for cradle and tray; 45% for adapters.  Wall count and orientation matter
  more than simply raising infill.
- Print the tray, cradle, collars, and pads as exported.  Print each adapter on its broad side as
  exported so the hook/clamp load stays mainly within continuous roads.
- Supports: none for the tray/cradle/fit collar.  Build-plate-only support may help the recessed
  nut pockets on an adapter depending on bridging calibration.

## Physical test before everyday use

1. Test empty, then with the radio switched off over a pillow or folded towel.
2. Pull upward and sideways gently; confirm the cradle screws, clamp, and drawer hook do not shift.
3. Increase load gradually to the actual radio mass.  Recheck after 1 hour and 24 hours for PETG creep.
4. For the tray, test the combined radio plus sealed can before using an open drink.
5. Keep the drawer stationary.  Moving/slamming the drawer can spill a drink and sharply multiplies
   the load on the printed parts and drawer slides.

Do not charge a hot, swollen, damaged, or unattended battery in a printed holder.  These parts are
prototype furniture accessories, not certified load-rated mounts.
"""
    (DOC_DIR / "PRINT_AND_ASSEMBLY.md").write_text(instructions, encoding="utf-8")

    engineering = """# Engineering notes

The measured radio envelope used here is 62.07 mm maximum photographed width, 40.37 mm depth,
and 157.73 mm body height.  The lower body was photographed at 58.01 mm wide.  The shared opening
is 64.0 x 43.5 mm, leaving 1.93 mm total width clearance and 3.13 mm total depth clearance.

For a screening calculation only, a 0.40 kg can at 57 mm, an assumed (not measured) 0.35 kg radio
at 49 mm, and 0.20 kg of small items at 100 mm create approximately 0.59 N·m static forward moment
about the drawer face.  A simple 2x bump screen is approximately 1.18 N·m.  This is not a verified
rating: the actual radio mass, printed layer bonding, PETG creep, drawer construction, and drawer
slides dominate the real safety margin.

The standalone cradle is intentionally shelf-supported.  Its two M5 fasteners do not carry the
radio weight by friction alone.  The drawer adapter has a broad 135 mm outside contact plate and
twin gussets.  The adjustable version uses two M8 pressure points to reduce yaw, but it remains
suitable only for flat and structurally sound edges.  Physical progressive load testing is required.
"""
    (DOC_DIR / "ENGINEERING_NOTES.md").write_text(engineering, encoding="utf-8")


def package_output() -> Path:
    # Build beside OUTPUT, then move it inside.  Creating a ZIP inside the tree
    # being archived would otherwise include a partial copy of itself.
    final_archive = OUTPUT / "drawer-radio-system-v3.zip"
    temporary_base = OUTPUT.parent / "drawer-radio-system-v3-package-temp"
    temporary_archive = Path(str(temporary_base) + ".zip")
    for path in (final_archive, temporary_archive):
        if path.exists():
            path.unlink()
    shutil.make_archive(str(temporary_base), "zip", root_dir=OUTPUT, base_dir=".")
    shutil.move(str(temporary_archive), str(final_archive))
    with zipfile.ZipFile(final_archive) as package:
        if package.testzip() is not None:
            raise RuntimeError("Generated ZIP failed its CRC integrity check")
        if any(name.endswith("drawer-radio-system-v3.zip") for name in package.namelist()):
            raise RuntimeError("Generated ZIP incorrectly contains itself")
    return final_archive


def main() -> int:
    make_dirs()
    print("Building radio system and v3 organizer solids...")
    parts, tray_p = build_parts(R)
    print("Exporting component STEP/STL files...")
    files = export_parts(parts, R)
    print("Exporting complete assemblies...")
    files.update(export_assemblies(parts, R))
    print("Rendering inspection views...")
    renders = render_all(parts, tray_p, R)
    print("Re-importing and validating geometry...")
    report = validate(parts, files, tray_p, R)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "validation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (REPORT_DIR / "radio_parameters.json").write_text(json.dumps(asdict(R), indent=2), encoding="utf-8")
    write_docs(R)
    # Include editable sources in the output package without changing the originals.
    shutil.copy2(ROOT / "radio_holder_system.py", OUTPUT / "radio_holder_system.py")
    shutil.copy2(ROOT / "drawer_organizer.py", OUTPUT / "drawer_organizer_v2_dependency.py")
    shutil.copy2(ROOT / "README.md", OUTPUT / "README.md")
    shutil.copy2(ROOT / "requirements.txt", OUTPUT / "requirements.txt")
    archive = package_output()
    print(json.dumps({
        "validation": report["status"],
        "output": str(OUTPUT),
        "archive": str(archive),
        "renders": [str(path) for path in renders],
    }, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
