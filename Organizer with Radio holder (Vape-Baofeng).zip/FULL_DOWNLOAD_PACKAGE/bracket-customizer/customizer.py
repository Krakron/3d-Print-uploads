"""Beginner-facing drawer-hook customizer for the four upload packages.

Only the drawer-fit geometry is regenerated.  Trays, cradles, platforms,
storage compartments, and their fastening coordinates remain the validated
source-revision sizes.
"""

from __future__ import annotations

import json
import importlib
import importlib.util
import math
import sys
from dataclasses import asdict, dataclass, replace
from datetime import datetime
from pathlib import Path
from typing import Any


MIN_DRAWER_THICKNESS_MM = 15.0
MAX_DRAWER_THICKNESS_MM = 30.0
NON_FIT_GEOMETRY_POLICY = "preserved-source-revision-values"
SETTING_KEYS = frozenset(
    {
        "drawer_front_thickness_mm",
        "extra_fit_clearance_mm",
        "compressed_padding_total_mm",
    }
)


@dataclass(frozen=True)
class DrawerSettings:
    drawer_front_thickness_mm: float
    extra_fit_clearance_mm: float
    compressed_padding_total_mm: float


def _strict_number(name: str, value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a JSON number, not {type(value).__name__}.")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite.")
    return result


def validate_drawer_settings(settings: DrawerSettings) -> None:
    thickness = _strict_number(
        "drawer_front_thickness_mm", settings.drawer_front_thickness_mm
    )
    extra = _strict_number(
        "extra_fit_clearance_mm", settings.extra_fit_clearance_mm
    )
    padding = _strict_number(
        "compressed_padding_total_mm", settings.compressed_padding_total_mm
    )
    if not MIN_DRAWER_THICKNESS_MM <= thickness <= MAX_DRAWER_THICKNESS_MM:
        raise ValueError(
            "drawer_front_thickness_mm must be between "
            f"{MIN_DRAWER_THICKNESS_MM:.1f} and {MAX_DRAWER_THICKNESS_MM:.1f} mm."
        )
    if extra < 0.0:
        raise ValueError("extra_fit_clearance_mm cannot be negative.")
    if padding < 0.0:
        raise ValueError("compressed_padding_total_mm cannot be negative.")
    clearance = thickness + extra + padding
    if clearance <= thickness:
        raise ValueError("The computed hook clearance must exceed drawer thickness.")


def computed_hook_clearance(settings: DrawerSettings) -> float:
    validate_drawer_settings(settings)
    return float(
        settings.drawer_front_thickness_mm
        + settings.extra_fit_clearance_mm
        + settings.compressed_padding_total_mm
    )


def load_drawer_settings(path: Path) -> DrawerSettings:
    try:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Could not read valid JSON settings: {exc}") from exc
    if not isinstance(document, dict):
        raise ValueError("Settings must be one JSON object.")
    keys = frozenset(document)
    missing = SETTING_KEYS - keys
    unknown = keys - SETTING_KEYS
    if missing or unknown:
        details: list[str] = []
        if missing:
            details.append("missing " + ", ".join(sorted(missing)))
        if unknown:
            details.append("unknown " + ", ".join(sorted(unknown)))
        raise ValueError("Invalid settings keys: " + "; ".join(details) + ".")
    settings = DrawerSettings(
        drawer_front_thickness_mm=_strict_number(
            "drawer_front_thickness_mm", document["drawer_front_thickness_mm"]
        ),
        extra_fit_clearance_mm=_strict_number(
            "extra_fit_clearance_mm", document["extra_fit_clearance_mm"]
        ),
        compressed_padding_total_mm=_strict_number(
            "compressed_padding_total_mm",
            document["compressed_padding_total_mm"],
        ),
    )
    validate_drawer_settings(settings)
    return settings


def _load_source_module(name: str, path: Path):
    resolved = Path(path).resolve()
    existing = sys.modules.get(name)
    if existing is not None and Path(getattr(existing, "__file__", "")).resolve() == resolved:
        return existing
    spec = importlib.util.spec_from_file_location(name, resolved)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load CAD source module {name} from {resolved}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return module


def _load_cad_modules(source_root: Path, package_id: str) -> dict[str, Any]:
    root = Path(source_root).resolve()
    root_text = str(root)
    if root_text not in sys.path:
        sys.path.insert(0, root_text)
    v2 = _load_source_module("drawer_organizer", root / "drawer_organizer.py")
    modules: dict[str, Any] = {"v2": v2}
    if package_id == "01-bedside-can-catchall-vape":
        return modules
    if package_id == "02-radio-holder-system":
        modules["v3"] = _load_source_module(
            "creality_source_radio_holder_system",
            root / "radio_holder_system.py",
        )
        return modules
    if package_id == "03-keyboard-mouse-platform":
        # V5 imports V4 by this canonical module name.
        modules["v4"] = _load_source_module(
            "keyboard_mouse_platform",
            root / "keyboard_mouse_platform.py",
        )
        modules["v5"] = _load_source_module(
            "creality_source_domed_hardware",
            root / "keyboard_mouse_platform_domed_hardware.py",
        )
        return modules
    if package_id != "04-deep-edc-organizer":
        raise ValueError(f"Unknown package_id: {package_id}")
    # The preserved V7/V8 sources enumerate this folder at import time.  It is
    # empty in a fresh standalone bundle and is not an input or output target.
    (root / "output").mkdir(exist_ok=True)
    v6 = _load_source_module(
        "bottom_drawer_edc_organizer",
        root / "bottom_drawer_edc_organizer.py",
    )
    v7 = _load_source_module(
        "bottom_drawer_edc_long_open_nut_brackets",
        root / "bottom_drawer_edc_long_open_nut_brackets.py",
    )
    v8 = _load_source_module(
        "creality_source_accessible_nut_brackets",
        root / "bottom_drawer_edc_accessible_nut_brackets.py",
    )
    modules.update({"v6": v6, "v7": v7, "v8": v8})
    return modules


def _simple_hook_coupon(
    box_xyz,
    clearance: float,
    wall: float,
    top: float,
    *,
    width: float = 30.0,
    outer_height: float = 38.0,
    inner_height: float = 25.0,
):
    """Make a single inexpensive U coupon whose opening is measurable."""

    inner_y_min = -(clearance + wall)
    outer = box_xyz(width, wall, outer_height + top, y_min=0.0, z_min=-outer_height)
    bridge = box_xyz(
        width,
        clearance + 2.0 * wall,
        top,
        y_min=inner_y_min,
        z_min=0.0,
    )
    inner = box_xyz(
        width,
        wall,
        inner_height + top,
        y_min=inner_y_min,
        z_min=-inner_height,
    )
    return outer.union(bridge).union(inner).clean()


def measure_coupon_nominal_clearance(package_id: str, coupon) -> float:
    walls = {
        "01-bedside-can-catchall-vape": 6.0,
        "02-radio-holder-system": 6.0,
        "03-keyboard-mouse-platform": 7.0,
        "04-deep-edc-organizer": 6.0,
    }
    try:
        wall = walls[package_id]
    except KeyError as exc:
        raise ValueError(f"Unknown package_id: {package_id}") from exc
    return float(coupon.val().BoundingBox().ylen - 2.0 * wall)


def mesh_connected_body_count(mesh) -> int:
    """Count mesh bodies without requiring an optional graph-engine package."""

    faces = mesh.faces
    if len(faces) == 0:
        return 0
    parent = list(range(len(mesh.vertices)))

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def union(left: int, right: int) -> None:
        left_root, right_root = find(left), find(right)
        if left_root != right_root:
            parent[right_root] = left_root

    used: set[int] = set()
    for a, b, c in faces:
        ia, ib, ic = int(a), int(b), int(c)
        used.update((ia, ib, ic))
        union(ia, ib)
        union(ib, ic)
    return len({find(index) for index in used})


def build_custom_parts(
    package_id: str,
    settings: DrawerSettings,
    source_root: Path,
) -> dict[str, Any]:
    """Build only the package's drawer-fit parts.

    Geometry adapters are implemented below the settings layer; keeping this
    public entry point in place lets invalid input fail before any output path
    is created.
    """

    validate_drawer_settings(settings)
    modules = _load_cad_modules(source_root, package_id)
    clearance = computed_hook_clearance(settings)
    thickness = float(settings.drawer_front_thickness_mm)

    if package_id == "01-bedside-can-catchall-vape":
        v2 = modules["v2"]
        parameters = replace(
            v2.P,
            drawer_front_thickness=thickness,
            hook_clearance=clearance,
        )
        return {
            "universal_drawer_bracket": v2.make_mounting_bracket(parameters),
            "drawer_fit_coupon": v2.make_fit_test(parameters),
        }

    if package_id == "02-radio-holder-system":
        v2, v3 = modules["v2"], modules["v3"]
        parameters = replace(
            v3.R,
            drawer_front_thickness=thickness,
            drawer_hook_clearance=clearance,
        )
        coupon = _simple_hook_coupon(
            v2.box_xyz,
            clearance,
            parameters.drawer_hook_wall,
            parameters.drawer_hook_top,
        )
        return {
            "fixed_drawer_adapter": v3.make_drawer_adapter(parameters),
            "drawer_fit_coupon": coupon,
        }

    if package_id == "03-keyboard-mouse-platform":
        v4, v5 = modules["v4"], modules["v5"]
        parameters = replace(
            v5.P,
            drawer_front_thickness=thickness,
            hook_clearance=clearance,
        )
        return {
            "keyboard_bracket": v5.make_insert_bracket("keyboard", parameters),
            "mouse_bracket": v5.make_insert_bracket("mouse", parameters),
            "drawer_fit_coupon": v4.make_hook_fit_test(parameters),
        }

    if package_id == "04-deep-edc-organizer":
        v6, v8 = modules["v6"], modules["v8"]
        original = v6.P
        parameters = replace(
            original,
            drawer_front_thickness=thickness,
            hook_clearance=clearance,
            hook_coupon_clearances=(clearance - 0.5, clearance, clearance + 0.5),
        )
        try:
            v6.P = parameters
            bracket = v8.make_accessible_bracket(v8.P)
        finally:
            v6.P = original
        coupon = _simple_hook_coupon(
            v6.box_xyz,
            clearance,
            parameters.hook_wall_thickness,
            parameters.hook_top_thickness,
        )
        return {
            "accessible_v8_bracket": bracket,
            "drawer_fit_coupon": coupon,
        }

    raise ValueError(f"Unknown package_id: {package_id}")


def export_custom_parts(
    package_id: str,
    settings: DrawerSettings,
    source_root: Path,
    output_root: Path,
) -> dict[str, Path]:
    """Validate first, then export custom parts to an isolated directory."""

    validate_drawer_settings(settings)
    parts = build_custom_parts(package_id, settings, source_root)
    modules = _load_cad_modules(source_root, package_id)
    from cadquery import exporters

    base = Path(output_root).resolve()
    base.mkdir(parents=True, exist_ok=True)
    while True:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        destination = base / f"{package_id}-custom-{stamp}"
        try:
            destination.mkdir(parents=False, exist_ok=False)
            break
        except FileExistsError:
            continue
    stl_dir = destination / "stl"
    step_dir = destination / "step"
    stl_dir.mkdir()
    step_dir.mkdir()

    files: dict[str, Path] = {"directory": destination}
    if package_id == "01-bedside-can-catchall-vape":
        orient = lambda name, shape: modules["v2"].oriented_for_print(shape, "side")
        linear = modules["v2"].P.stl_linear_tolerance
        angular = modules["v2"].P.stl_angular_tolerance
    elif package_id == "02-radio-holder-system":
        orient = lambda name, shape: modules["v3"].oriented(shape, "side")
        linear = modules["v3"].R.stl_linear_tolerance
        angular = modules["v3"].R.stl_angular_tolerance
    elif package_id == "03-keyboard-mouse-platform":
        orient = lambda name, shape: modules["v4"].oriented(shape, "side")
        linear = modules["v5"].P.stl_linear_tolerance
        angular = modules["v5"].P.stl_angular_tolerance
    elif package_id == "04-deep-edc-organizer":
        orient = lambda name, shape: modules["v8"].oriented_for_print(
            "accessible_bracket" if name == "accessible_v8_bracket" else "nut_fit_coupon",
            shape,
            modules["v8"].P,
        )
        linear = modules["v6"].P.stl_linear_tolerance
        angular = modules["v6"].P.stl_angular_tolerance
    else:
        raise ValueError(f"Unknown package_id: {package_id}")

    for name, shape in parts.items():
        step_path = step_dir / f"{name}.step"
        stl_path = stl_dir / f"{name}_print_oriented.stl"
        exporters.export(shape, str(step_path))
        exporters.export(
            orient(name, shape),
            str(stl_path),
            tolerance=linear,
            angularTolerance=angular,
        )
        files[f"step_{name}"] = step_path
        files[f"stl_{name}"] = stl_path

    settings_path = destination / "drawer_settings_used.json"
    snapshot = asdict(settings)
    snapshot.update(
        {
            "package_id": package_id,
            "computed_hook_clearance_mm": computed_hook_clearance(settings),
            "non_fit_geometry_policy": NON_FIT_GEOMETRY_POLICY,
        }
    )
    settings_path.write_text(
        json.dumps(snapshot, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    files["settings"] = settings_path
    return files
