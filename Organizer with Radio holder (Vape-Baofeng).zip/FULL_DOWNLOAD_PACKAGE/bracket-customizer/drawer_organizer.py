"""Parametric drawer-mounted bedside organizer generated with CadQuery.

Coordinate system used for the design/assembly:
    X: horizontal along the drawer front
    Y: outward from the drawer toward the bed (drawer outer face is Y=0)
    Z: upward (drawer top is Z=0)

This v2 variant adds a deep rounded-rectangle vape sleeve while preserving the
field-tested mount, can well, and tray envelope from v1. The tray and two hook
brackets are separate printable parts. Four M5 screws
pass through horizontal slots in the tray into captured M5 nuts in the bracket
shelves. The slots provide physical left/right adjustment; the named
``bracket_spacing`` parameter sets the nominal positions.

Run:
    python drawer_organizer.py

The script writes STEP/STL files, assembly STEP, PNG renders, and a validation
report under ``output/v2-vape/``. CadQuery 2.5.x and matplotlib are required; trimesh
is used for independent STL checks.
"""

from __future__ import annotations

import json
import math
import os
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cadquery as cq
from cadquery import exporters, importers


@dataclass(frozen=True)
class Parameters:
    # Confirmed/fit-critical drawer dimensions (millimetres)
    drawer_front_thickness: float = 20.85
    hook_clearance: float = 21.50

    # Mounting brackets
    hook_wall_thickness: float = 6.0
    hook_top_thickness: float = 6.0
    inside_hook_leg_length: float = 30.0
    vertical_brace_length: float = 135.0
    bracket_width: float = 22.0
    bracket_spacing: float = 160.0
    bracket_shelf_depth: float = 110.0
    bracket_shelf_thickness: float = 8.0
    gusset_rib_width: float = 8.0
    gusset_forward_reach: float = 102.0
    gusset_drop: float = 100.0
    root_boss_radius: float = 10.0

    # Tray envelope (205 mm width fits a typical 220 mm square build plate)
    tray_width: float = 205.0
    tray_depth: float = 140.0
    tray_base_thickness: float = 4.0
    structural_wall_thickness: float = 4.0
    catchall_wall_height: float = 12.0
    tray_bottom_z: float = -10.0
    tray_back_y: float = 6.0
    fillet_radius: float = 3.0

    # Can holder
    soda_holder_diameter: float = 70.0
    soda_holder_wall_thickness: float = 4.0
    soda_holder_wall_height: float = 42.0
    soda_center_x: float = -53.0
    soda_center_y: float = 57.0
    can_pad_diameter: float = 68.5
    can_pad_thickness: float = 1.5

    # Vape holder. User-measured body cross-section is 28.38 x 54.46 mm.
    # The larger internal values provide roughly 1.3-1.5 mm clearance per side.
    vape_measured_width: float = 28.38
    vape_measured_length: float = 54.46
    vape_holder_internal_width: float = 31.0
    vape_holder_internal_length: float = 57.5
    vape_holder_wall_thickness: float = 4.0
    vape_holder_depth: float = 42.0
    vape_holder_inner_radius: float = 4.5
    vape_center_x: float = 29.0
    vape_center_y: float = 49.0
    vape_pad_edge_clearance: float = 1.2
    vape_pad_thickness: float = 1.5
    vape_fit_test_height: float = 12.0

    # Catchall/remote bay. Its usable plan area is calculated from the divider.
    divider_x: float = -10.0
    divider_thickness: float = 4.0

    # M5 bracket joint and assembly clearances
    bolt_nominal_diameter: float = 5.0
    bolt_clearance: float = 0.55
    bolt_slot_length: float = 26.0
    bolt_y_near: float = 16.0
    bolt_y_far: float = 104.0
    nut_across_flats: float = 8.2
    nut_clearance: float = 0.35
    nut_thickness: float = 4.0
    nut_depth_clearance: float = 0.35

    # Recesses accept flush adhesive pads; pads thicker than recess depth reduce fit.
    pad_recess_depth: float = 0.8
    pad_side_margin: float = 2.5

    # Cheap single-hook fit coupon
    fit_test_width: float = 30.0
    fit_test_outer_leg_length: float = 38.0
    fit_test_inner_leg_length: float = 25.0

    # Export quality
    stl_linear_tolerance: float = 0.08
    stl_angular_tolerance: float = 0.12


P = Parameters()
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output" / "v2-vape"
STL_DIR = OUTPUT / "stl"
STEP_DIR = OUTPUT / "step"
RENDER_DIR = OUTPUT / "renders"
REPORT_DIR = OUTPUT / "reports"
DOC_DIR = OUTPUT / "docs"


def make_dirs() -> None:
    for directory in (STL_DIR, STEP_DIR, RENDER_DIR, REPORT_DIR, DOC_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def box_xyz(
    x_len: float,
    y_len: float,
    z_len: float,
    *,
    x_center: float = 0.0,
    y_min: float = 0.0,
    z_min: float = 0.0,
) -> cq.Workplane:
    """Create an axis-aligned box with X centred and Y/Z located by minima."""
    return (
        cq.Workplane("XY")
        .box(x_len, y_len, z_len, centered=(True, False, False))
        .translate((x_center, y_min, z_min))
    )


def horizontal_slot_cutter(
    x_center: float, y_center: float, z_min: float, height: float, length: float, diameter: float
) -> cq.Workplane:
    """Capsule slot running in X, suitable for a vertically inserted bolt."""
    straight = max(0.0, length - diameter)
    middle = box_xyz(straight, diameter, height, x_center=x_center, y_min=y_center - diameter / 2, z_min=z_min)
    left = (
        cq.Workplane("XY")
        .center(x_center - straight / 2, y_center)
        .circle(diameter / 2)
        .extrude(height)
        .translate((0, 0, z_min))
    )
    right = (
        cq.Workplane("XY")
        .center(x_center + straight / 2, y_center)
        .circle(diameter / 2)
        .extrude(height)
        .translate((0, 0, z_min))
    )
    return middle.union(left).union(right)


def rounded_rectangle_prism(
    x_size: float,
    y_size: float,
    radius: float,
    height: float,
    *,
    x_center: float = 0.0,
    y_center: float = 0.0,
    z_min: float = 0.0,
) -> cq.Workplane:
    """Robust rounded-rectangle prism made from boxes and four cylinders."""
    if radius <= 0 or 2 * radius >= min(x_size, y_size):
        raise ValueError("Rounded-rectangle radius must be positive and less than half the short side")
    horizontal = box_xyz(x_size, y_size - 2 * radius, height,
                         x_center=x_center, y_min=y_center - y_size / 2 + radius,
                         z_min=z_min)
    vertical = box_xyz(x_size - 2 * radius, y_size, height,
                       x_center=x_center, y_min=y_center - y_size / 2,
                       z_min=z_min)
    result = horizontal.union(vertical)
    for dx in (-x_size / 2 + radius, x_size / 2 - radius):
        for dy in (-y_size / 2 + radius, y_size / 2 - radius):
            corner = (
                cq.Workplane("XY")
                .center(x_center + dx, y_center + dy)
                .circle(radius)
                .extrude(height)
                .translate((0, 0, z_min))
            )
            result = result.union(corner)
    return result.clean()


def make_vape_wall(p: Parameters = P, height: float | None = None) -> cq.Workplane:
    """Rounded sleeve wall sized from the measured vape cross-section."""
    wall_h = p.vape_holder_depth if height is None else height
    z_top = p.tray_bottom_z + p.tray_base_thickness
    outer_w = p.vape_holder_internal_width + 2 * p.vape_holder_wall_thickness
    outer_l = p.vape_holder_internal_length + 2 * p.vape_holder_wall_thickness
    outer_r = p.vape_holder_inner_radius + p.vape_holder_wall_thickness
    outer = rounded_rectangle_prism(
        outer_w, outer_l, outer_r, wall_h,
        x_center=p.vape_center_x, y_center=p.vape_center_y, z_min=z_top,
    )
    inner = rounded_rectangle_prism(
        p.vape_holder_internal_width, p.vape_holder_internal_length,
        p.vape_holder_inner_radius, wall_h + 1.0,
        x_center=p.vape_center_x, y_center=p.vape_center_y, z_min=z_top,
    )
    sleeve = outer.cut(inner)
    try:
        sleeve = sleeve.edges(">Z").chamfer(1.0)
    except Exception:
        pass
    return sleeve.clean()


def make_tray(p: Parameters = P) -> cq.Workplane:
    """One-piece tray with can well, vape sleeve, catchall, and bolt slots."""
    t = p.structural_wall_thickness
    z0 = p.tray_bottom_z
    z_top = z0 + p.tray_base_thickness
    y0 = p.tray_back_y
    outer_can_d = p.soda_holder_diameter + 2 * p.soda_holder_wall_thickness

    base = box_xyz(p.tray_width, p.tray_depth, p.tray_base_thickness, y_min=y0, z_min=z0)

    # Perimeter walls. The rear wall is intentionally low enough not to obstruct
    # the top hook cap, while still keeping small objects on the tray.
    wall_h = p.catchall_wall_height
    rear = box_xyz(p.tray_width, t, wall_h, y_min=y0, z_min=z_top)
    front = box_xyz(p.tray_width, t, wall_h, y_min=y0 + p.tray_depth - t, z_min=z_top)
    left = box_xyz(t, p.tray_depth - 2 * t, wall_h, x_center=-p.tray_width / 2 + t / 2,
                   y_min=y0 + t, z_min=z_top)
    right = box_xyz(t, p.tray_depth - 2 * t, wall_h, x_center=p.tray_width / 2 - t / 2,
                    y_min=y0 + t, z_min=z_top)
    divider = box_xyz(p.divider_thickness, p.tray_depth - 2 * t, wall_h,
                      x_center=p.divider_x, y_min=y0 + t, z_min=z_top)

    # A genuine 42 mm-high retaining wall, not a decorative ring. The base is
    # kept solid beneath it. Chamfering the top edge improves one-handed entry.
    outer = (
        cq.Workplane("XY")
        .center(p.soda_center_x, p.soda_center_y)
        .circle(outer_can_d / 2)
        .extrude(p.soda_holder_wall_height)
        .translate((0, 0, z_top))
    )
    inner = (
        cq.Workplane("XY")
        .center(p.soda_center_x, p.soda_center_y)
        .circle(p.soda_holder_diameter / 2)
        .extrude(p.soda_holder_wall_height + 1.0)
        .translate((0, 0, z_top))
    )
    can_wall = outer.cut(inner)
    try:
        can_wall = can_wall.edges("%CIRCLE and >Z").chamfer(1.2)
    except Exception:
        # The retaining geometry remains valid if an OCC version cannot select
        # that circular edge; validation records dimensions independently.
        pass

    vape_wall = make_vape_wall(p)
    tray = (
        base.union(rear).union(front).union(left).union(right)
        .union(divider).union(can_wall).union(vape_wall)
    )

    # Two slots per bracket. Large washers under socket-head screws bridge the
    # slots; the captured nuts below prevent a friction-only structural joint.
    slot_d = p.bolt_nominal_diameter + p.bolt_clearance
    slot_h = p.tray_base_thickness + 2.0
    for bx in (-p.bracket_spacing / 2, p.bracket_spacing / 2):
        for by in (p.bolt_y_near, p.bolt_y_far):
            tray = tray.cut(horizontal_slot_cutter(bx, by, z0 - 1.0, slot_h,
                                                   p.bolt_slot_length, slot_d))

    # Conservative external corner rounding on long tray edges.
    try:
        tray = tray.edges("|Z").fillet(min(p.fillet_radius, 3.0))
    except Exception:
        pass
    return tray.clean()


def make_mounting_bracket(p: Parameters = P) -> cq.Workplane:
    """Reinforced inverted-U bracket, modelled at X=0 for later placement."""
    w = p.bracket_width
    hw = p.hook_wall_thickness
    z_shelf_top = p.tray_bottom_z
    z_shelf_bottom = z_shelf_top - p.bracket_shelf_thickness

    # Outside leg: broad drawer contact down 135 mm.
    outer_leg = box_xyz(w, hw, p.vertical_brace_length + p.hook_top_thickness,
                        y_min=0.0, z_min=-p.vertical_brace_length)
    # Hook top and inner leg create the exact user-editable internal clearance.
    hook_y_min = -(p.hook_clearance + hw)
    top_cap = box_xyz(w, p.hook_clearance + 2 * hw, p.hook_top_thickness,
                      y_min=hook_y_min, z_min=0.0)
    inner_leg = box_xyz(w, hw, p.inside_hook_leg_length + p.hook_top_thickness,
                        y_min=hook_y_min, z_min=-p.inside_hook_leg_length)

    # Shelf sits directly under the tray base and carries two M5 fasteners.
    shelf = box_xyz(w, p.bracket_shelf_depth - hw, p.bracket_shelf_thickness,
                    y_min=hw, z_min=z_shelf_bottom)

    # Central triangular rib transfers cantilever moment far down the broad leg.
    rib = (
        cq.Workplane("YZ")
        .moveTo(hw, z_shelf_bottom)
        .lineTo(hw + p.gusset_forward_reach, z_shelf_bottom)
        .lineTo(hw, z_shelf_bottom - p.gusset_drop)
        .close()
        .extrude(p.gusset_rib_width)
        .translate((-p.gusset_rib_width / 2, 0, 0))
    )

    # Full-width cylindrical root boss removes the sharp 90-degree shelf/leg
    # transition and provides a generous printed load path.
    boss = (
        cq.Workplane("YZ")
        # One millimetre of overlap into the outside leg avoids a merely tangent
        # union, which can triangulate as a non-manifold edge in STL.
        .center(hw + p.root_boss_radius - 1.0, z_shelf_top - p.root_boss_radius)
        .circle(p.root_boss_radius)
        .extrude(w)
        .translate((-w / 2, 0, 0))
    )

    bracket = outer_leg.union(top_cap).union(inner_leg).union(shelf).union(rib).union(boss)

    # Bolt holes and bottom-access captured hex nuts.
    bolt_d = p.bolt_nominal_diameter + p.bolt_clearance
    nut_flat = p.nut_across_flats + p.nut_clearance
    nut_vertex_d = nut_flat / math.cos(math.radians(30.0))
    pocket_depth = p.nut_thickness + p.nut_depth_clearance
    for by in (p.bolt_y_near, p.bolt_y_far):
        hole = (
            cq.Workplane("XY")
            .center(0.0, by)
            .circle(bolt_d / 2)
            .extrude(p.bracket_shelf_thickness + 2.0)
            .translate((0, 0, z_shelf_bottom - 1.0))
        )
        pocket = (
            cq.Workplane("XY")
            .center(0.0, by)
            .polygon(6, nut_vertex_d)
            .extrude(pocket_depth)
            .translate((0, 0, z_shelf_bottom - 0.01))
        )
        bracket = bracket.cut(hole).cut(pocket)

    # Flush pad recesses. Pads at the recess depth do not reduce hook clearance.
    recess_w = w - 2 * p.pad_side_margin
    outside_pad = box_xyz(recess_w, p.pad_recess_depth, 62.0,
                          y_min=-0.01, z_min=-116.0)
    inside_pad = box_xyz(recess_w, p.pad_recess_depth + 0.01, 17.0,
                         y_min=hook_y_min + hw - p.pad_recess_depth,
                         z_min=-24.0)
    top_pad = box_xyz(recess_w, p.hook_clearance - 2.0, p.pad_recess_depth + 0.01,
                      y_min=-p.hook_clearance + 1.0, z_min=-0.01)
    bracket = bracket.cut(outside_pad).cut(inside_pad).cut(top_pad)
    return bracket.clean()


def make_fit_test(p: Parameters = P) -> cq.Workplane:
    """Low-material hook coupon using the same clearance and contact geometry."""
    w = p.fit_test_width
    hw = p.hook_wall_thickness
    hook_y_min = -(p.hook_clearance + hw)
    outside = box_xyz(w, hw, p.fit_test_outer_leg_length + p.hook_top_thickness,
                      y_min=0.0, z_min=-p.fit_test_outer_leg_length)
    inside = box_xyz(w, hw, p.fit_test_inner_leg_length + p.hook_top_thickness,
                     y_min=hook_y_min, z_min=-p.fit_test_inner_leg_length)
    top = box_xyz(w, p.hook_clearance + 2 * hw, p.hook_top_thickness,
                  y_min=hook_y_min, z_min=0.0)
    coupon = outside.union(inside).union(top)
    # Short flush pad recesses duplicate the production bracket contact faces.
    recess_w = w - 2 * p.pad_side_margin
    coupon = coupon.cut(box_xyz(recess_w, p.pad_recess_depth, 18.0,
                                y_min=-0.01, z_min=-29.0))
    coupon = coupon.cut(box_xyz(recess_w, p.pad_recess_depth + 0.01, 13.0,
                                y_min=hook_y_min + hw - p.pad_recess_depth,
                                z_min=-19.0))
    coupon = coupon.cut(box_xyz(recess_w, p.hook_clearance - 2.0,
                                p.pad_recess_depth + 0.01,
                                y_min=-p.hook_clearance + 1.0, z_min=-0.01))
    return coupon.clean()


def make_can_pad(p: Parameters = P) -> cq.Workplane:
    """Optional removable TPU disk with shallow concentric grip grooves."""
    disk = cq.Workplane("XY").circle(p.can_pad_diameter / 2).extrude(p.can_pad_thickness)
    # Two shallow grooves retain flexibility while breaking up a wet contact film.
    for diameter in (36.0, 54.0):
        groove = (
            cq.Workplane("XY")
            .circle(diameter / 2 + 0.55)
            .circle(diameter / 2 - 0.55)
            .extrude(0.45)
            .translate((0, 0, p.can_pad_thickness - 0.45))
        )
        disk = disk.cut(groove)
    return disk.clean()


def make_vape_pad(p: Parameters = P) -> cq.Workplane:
    """Optional TPU bottom pad for the vape sleeve."""
    width = p.vape_holder_internal_width - p.vape_pad_edge_clearance
    length = p.vape_holder_internal_length - p.vape_pad_edge_clearance
    radius = max(1.0, p.vape_holder_inner_radius - p.vape_pad_edge_clearance / 2)
    return rounded_rectangle_prism(width, length, radius, p.vape_pad_thickness).clean()


def make_vape_fit_test(p: Parameters = P) -> cq.Workplane:
    """Low-material collar to confirm the measured vape cross-section fit."""
    outer_w = p.vape_holder_internal_width + 2 * p.vape_holder_wall_thickness
    outer_l = p.vape_holder_internal_length + 2 * p.vape_holder_wall_thickness
    outer_r = p.vape_holder_inner_radius + p.vape_holder_wall_thickness
    outer = rounded_rectangle_prism(
        outer_w, outer_l, outer_r, p.vape_fit_test_height,
    )
    inner = rounded_rectangle_prism(
        p.vape_holder_internal_width, p.vape_holder_internal_length,
        p.vape_holder_inner_radius, p.vape_fit_test_height + 1.0,
        z_min=-0.5,
    )
    return outer.cut(inner).clean()


def oriented_for_print(shape: cq.Workplane, mode: str) -> cq.Workplane:
    """Return a copy in the recommended FDM orientation with Zmin=0."""
    result = shape
    if mode == "side":
        # Bracket profile lies in the YZ plane; laying that face on the bed keeps
        # primary cantilever stresses in continuous roads instead of layer peel.
        result = result.rotate((0, 0, 0), (0, 1, 0), 90)
    bb = result.val().BoundingBox()
    return result.translate((0, 0, -bb.zmin))


def make_hardware_reference(p: Parameters, x: float, y: float) -> cq.Workplane:
    """Simple non-printable M5 screw reference for assembly visualization."""
    z0 = p.tray_bottom_z - p.bracket_shelf_thickness
    shank = cq.Workplane("XY").center(x, y).circle(2.5).extrude(17.0).translate((0, 0, z0))
    head = cq.Workplane("XY").center(x, y).circle(5.0).extrude(3.0).translate((0, 0, p.tray_bottom_z + p.tray_base_thickness))
    return shank.union(head)


def build_parts(p: Parameters = P) -> Dict[str, cq.Workplane]:
    tray = make_tray(p)
    bracket = make_mounting_bracket(p)
    fit = make_fit_test(p)
    pad = make_can_pad(p)
    vape_pad = make_vape_pad(p)
    vape_fit = make_vape_fit_test(p)
    return {
        "tray": tray,
        "bracket": bracket,
        "fit_test": fit,
        "can_pad": pad,
        "vape_pad": vape_pad,
        "vape_fit_test": vape_fit,
    }


def export_parts(parts: Dict[str, cq.Workplane], p: Parameters = P) -> Dict[str, Path]:
    files: Dict[str, Path] = {}

    # STEP component models remain in assembly/design coordinates.
    step_map = {
        "tray": "organizer_tray_with_vape_holder.step",
        "bracket": "mounting_bracket_universal_v2_unchanged.step",
        "fit_test": "drawer_hook_fit_test_21p5mm_v2_unchanged.step",
        "can_pad": "optional_can_base_pad_v2.step",
        "vape_pad": "optional_vape_bottom_pad_tpu.step",
        "vape_fit_test": "vape_fit_test_31x57p5mm.step",
    }
    for key, filename in step_map.items():
        path = STEP_DIR / filename
        exporters.export(parts[key], str(path))
        files[f"step_{key}"] = path

    # STL models are exported already oriented for the slicer.
    stl_shapes = {
        "tray": oriented_for_print(parts["tray"], "base"),
        "bracket_left": oriented_for_print(parts["bracket"], "side"),
        "bracket_right": oriented_for_print(parts["bracket"], "side"),
        "fit_test": oriented_for_print(parts["fit_test"], "side"),
        "can_pad": oriented_for_print(parts["can_pad"], "base"),
        "vape_pad": oriented_for_print(parts["vape_pad"], "base"),
        "vape_fit_test": oriented_for_print(parts["vape_fit_test"], "base"),
    }
    stl_map = {
        "tray": "organizer_tray_with_vape_holder_print_flat.stl",
        "bracket_left": "mounting_bracket_left_v2_unchanged_print_on_side.stl",
        "bracket_right": "mounting_bracket_right_v2_unchanged_print_on_side.stl",
        "fit_test": "drawer_hook_fit_test_21p5mm_v2_unchanged_print_on_side.stl",
        "can_pad": "optional_can_base_pad_v2_tpu.stl",
        "vape_pad": "optional_vape_bottom_pad_tpu.stl",
        "vape_fit_test": "vape_fit_test_31x57p5mm_print_flat.stl",
    }
    for key, shape in stl_shapes.items():
        path = STL_DIR / stl_map[key]
        exporters.export(shape, str(path), tolerance=p.stl_linear_tolerance,
                         angularTolerance=p.stl_angular_tolerance)
        files[f"stl_{key}"] = path

    return files


def make_assembly(parts: Dict[str, cq.Workplane], p: Parameters = P) -> cq.Assembly:
    assembly = cq.Assembly(name="drawer_mounted_bedside_organizer_with_vape_holder")
    assembly.add(parts["tray"], name="tray_with_vape_holder", color=cq.Color(0.16, 0.39, 0.65))
    for side, x in (("left", -p.bracket_spacing / 2), ("right", p.bracket_spacing / 2)):
        assembly.add(parts["bracket"], name=f"bracket_{side}",
                     loc=cq.Location(cq.Vector(x, 0, 0)), color=cq.Color(0.11, 0.27, 0.48))
        for index, y in enumerate((p.bolt_y_near, p.bolt_y_far), 1):
            assembly.add(make_hardware_reference(p, x, y), name=f"M5_{side}_{index}",
                         color=cq.Color(0.68, 0.70, 0.73))
    pad_loc = cq.Location(cq.Vector(p.soda_center_x, p.soda_center_y,
                                    p.tray_bottom_z + p.tray_base_thickness))
    assembly.add(parts["can_pad"], name="optional_TPU_can_pad", loc=pad_loc,
                 color=cq.Color(0.12, 0.12, 0.12))
    vape_pad_loc = cq.Location(cq.Vector(
        p.vape_center_x, p.vape_center_y,
        p.tray_bottom_z + p.tray_base_thickness,
    ))
    assembly.add(parts["vape_pad"], name="optional_TPU_vape_pad", loc=vape_pad_loc,
                 color=cq.Color(0.10, 0.10, 0.10))
    return assembly


def export_assembly(assembly: cq.Assembly) -> Path:
    path = STEP_DIR / "drawer_mounted_bedside_organizer_with_vape_complete_assembly.step"
    assembly.save(str(path), mode="default")
    return path


def shape_mesh(shape: cq.Shape, tolerance: float = 0.35):
    """Return NumPy vertex/triangle arrays from an OCC shape tessellation."""
    import numpy as np

    vertices, triangles = shape.tessellate(tolerance)
    vv = np.array([[v.x, v.y, v.z] for v in vertices], dtype=float)
    tt = np.array(triangles, dtype=int)
    return vv, tt


def add_shape_to_axis(ax, shape: cq.Shape, color: str, alpha: float = 1.0) -> None:
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    vertices, triangles = shape_mesh(shape)
    faces = vertices[triangles]
    poly = Poly3DCollection(faces, facecolor=color, edgecolor=(0.08, 0.08, 0.08, 0.15),
                            linewidth=0.12, alpha=alpha)
    ax.add_collection3d(poly)


def set_axes_equal(ax, bounds: Sequence[Tuple[float, float]]) -> None:
    centers = [(a + b) / 2 for a, b in bounds]
    span = max(b - a for a, b in bounds) / 2
    ax.set_xlim(centers[0] - span, centers[0] + span)
    ax.set_ylim(centers[1] - span, centers[1] + span)
    ax.set_zlim(centers[2] - span, centers[2] + span)
    ax.set_box_aspect((1, 1, 1))


def render_scene(
    filename: str,
    scene: Sequence[Tuple[cq.Shape, str, float]],
    *,
    elev: float,
    azim: float,
    bounds: Sequence[Tuple[float, float]],
    title: str,
) -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(10, 8), dpi=170)
    ax = fig.add_subplot(111, projection="3d", computed_zorder=False)
    for shape, color, alpha in scene:
        add_shape_to_axis(ax, shape, color, alpha)
    set_axes_equal(ax, bounds)
    ax.view_init(elev=elev, azim=azim)
    ax.set_axis_off()
    ax.set_title(title, pad=16)
    fig.patch.set_facecolor("#f5f4f0")
    ax.set_facecolor("#f5f4f0")
    plt.tight_layout()
    path = RENDER_DIR / filename
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def render_all(parts: Dict[str, cq.Workplane], p: Parameters = P) -> List[Path]:
    tray_shape = parts["tray"].val()
    left = parts["bracket"].translate((-p.bracket_spacing / 2, 0, 0)).val()
    right = parts["bracket"].translate((p.bracket_spacing / 2, 0, 0)).val()
    pad = parts["can_pad"].translate((p.soda_center_x, p.soda_center_y,
                                      p.tray_bottom_z + p.tray_base_thickness)).val()
    vape_pad = parts["vape_pad"].translate((p.vape_center_x, p.vape_center_y,
                                            p.tray_bottom_z + p.tray_base_thickness)).val()
    base_scene = [
        (tray_shape, "#2d79bd", 1.0),
        (left, "#1c4f82", 1.0),
        (right, "#1c4f82", 1.0),
        (pad, "#2c2c2c", 1.0),
        (vape_pad, "#26232b", 1.0),
    ]
    bounds = ((-125, 125), (-45, 160), (-150, 70))
    paths = [
        render_scene("organizer_with_vape_isometric.png", base_scene, elev=24, azim=-56,
                     bounds=bounds, title="Drawer organizer v2 — can well, vape sleeve, and catchall"),
        render_scene("organizer_with_vape_top.png", base_scene, elev=88, azim=-90,
                     bounds=bounds, title="Top view — 31 x 57.5 mm vape sleeve opening"),
        render_scene("organizer_with_vape_front_supports.png", base_scene, elev=8, azim=-88,
                     bounds=bounds, title="Side/front view — twin hooks and reinforced gussets"),
    ]

    # Installed-position visualization: simplified, explicitly non-measured drawer.
    drawer_front = box_xyz(420.0, p.drawer_front_thickness, 200.0,
                           y_min=-p.drawer_front_thickness, z_min=-200.0).val()
    handle = box_xyz(110.0, 8.0, 26.0, y_min=0.0, z_min=-62.0).val()
    drawer_bottom = box_xyz(390.0, 280.0, 10.0, y_min=-300.0, z_min=-185.0).val()
    can = (
        cq.Workplane("XY").center(p.soda_center_x, p.soda_center_y)
        .circle(33.0).extrude(122.0)
        .translate((0, 0, p.tray_bottom_z + p.tray_base_thickness + p.can_pad_thickness))
        .val()
    )
    # Device height is illustrative; only its photographed cross-section was measured.
    vape_device = rounded_rectangle_prism(
        p.vape_measured_width, p.vape_measured_length, 4.0, 96.0,
        x_center=p.vape_center_x, y_center=p.vape_center_y,
        z_min=p.tray_bottom_z + p.tray_base_thickness + p.vape_pad_thickness,
    ).val()
    remote = box_xyz(42.0, 48.0, 13.0, x_center=74.0, y_min=88.0,
                     z_min=p.tray_bottom_z + p.tray_base_thickness).val()
    installed_scene = [
        (drawer_bottom, "#8b5a35", 0.32),
        (drawer_front, "#8a552f", 0.92),
        (handle, "#b9bcc0", 1.0),
        *base_scene,
        (can, "#d64a3d", 0.96),
        (vape_device, "#3b3348", 0.98),
        (remote, "#222222", 0.96),
    ]
    paths.append(render_scene(
        "installed_position_with_vape_simplified_drawer.png", installed_scene,
        elev=20, azim=-48, bounds=((-225, 225), (-315, 165), (-215, 135)),
        title="Installed v2 visualization (drawer, handle, and vape height are illustrative)",
    ))
    return paths


def validate(parts: Dict[str, cq.Workplane], files: Dict[str, Path], p: Parameters = P) -> Dict:
    import trimesh

    report: Dict = {
        "status": "PASS",
        "parameters_mm": asdict(p),
        "solid_checks": {},
        "mesh_checks": {},
        "step_reimport_checks": {},
        "dimensional_checks": {},
        "assembly_checks": {},
        "mass_estimate": {},
        "warnings": [],
    }

    for name, workplane in parts.items():
        shape = workplane.val()
        solids = shape.Solids()
        bb = shape.BoundingBox()
        entry = {
            "solid_count": len(solids),
            "valid": bool(shape.isValid()),
            "volume_mm3": round(shape.Volume(), 2),
            "bounding_box_mm": [round(bb.xlen, 3), round(bb.ylen, 3), round(bb.zlen, 3)],
        }
        if not entry["valid"] or entry["solid_count"] != 1 or entry["volume_mm3"] <= 0:
            report["status"] = "FAIL"
        report["solid_checks"][name] = entry

    for key, path in files.items():
        if not key.startswith("stl_"):
            continue
        # CadQuery writes a valid triangle soup with duplicated per-face vertices.
        # Trimesh's processing step welds coincident vertices before its topology
        # test, which is the meaningful watertightness check for exported STL.
        mesh = trimesh.load_mesh(path, process=True)
        extents = [round(float(v), 3) for v in mesh.extents]
        entry = {
            "vertices": int(len(mesh.vertices)),
            "faces": int(len(mesh.faces)),
            "watertight": bool(mesh.is_watertight),
            "winding_consistent": bool(mesh.is_winding_consistent),
            "volume_mm3": round(abs(float(mesh.volume)), 2),
            "bounding_box_mm": extents,
        }
        if not entry["watertight"] or entry["faces"] == 0:
            report["status"] = "FAIL"
        report["mesh_checks"][path.name] = entry

    for key, path in files.items():
        if not key.startswith("step_"):
            continue
        imported = importers.importStep(str(path)).val()
        entry = {
            "valid": bool(imported.isValid()),
            "solid_count": len(imported.Solids()),
            "volume_mm3": round(imported.Volume(), 2),
        }
        if not entry["valid"] or entry["solid_count"] < 1:
            report["status"] = "FAIL"
        report["step_reimport_checks"][path.name] = entry

    # Direct design-intent checks guard against a geometrically valid but wrong export.
    bracket_bb = parts["bracket"].val().BoundingBox()
    tray_bb = parts["tray"].val().BoundingBox()
    holder_outer = p.soda_holder_diameter + 2 * p.soda_holder_wall_thickness
    report["dimensional_checks"] = {
        "hook_internal_clearance_mm": p.hook_clearance,
        "drawer_front_thickness_mm": p.drawer_front_thickness,
        "nominal_bare_fit_slack_mm": round(p.hook_clearance - p.drawer_front_thickness, 3),
        "tray_plan_mm": [round(tray_bb.xlen, 3), round(tray_bb.ylen, 3)],
        "holder_internal_diameter_mm": p.soda_holder_diameter,
        "holder_outer_diameter_mm": holder_outer,
        "holder_wall_height_mm": p.soda_holder_wall_height,
        "vape_measured_cross_section_mm": [p.vape_measured_width, p.vape_measured_length],
        "vape_holder_internal_cross_section_mm": [
            p.vape_holder_internal_width, p.vape_holder_internal_length,
        ],
        "vape_total_width_clearance_mm": round(
            p.vape_holder_internal_width - p.vape_measured_width, 3
        ),
        "vape_total_length_clearance_mm": round(
            p.vape_holder_internal_length - p.vape_measured_length, 3
        ),
        "vape_insertion_depth_mm": p.vape_holder_depth,
        "vape_insertion_depth_in": round(p.vape_holder_depth / 25.4, 3),
        "bracket_vertical_extent_mm": round(bracket_bb.zlen, 3),
        "nominal_bracket_spacing_mm": p.bracket_spacing,
        "physical_horizontal_adjustment_per_bracket_mm": round(
            p.bolt_slot_length - (p.bolt_nominal_diameter + p.bolt_clearance), 3
        ),
    }
    if p.hook_clearance <= p.drawer_front_thickness:
        report["status"] = "FAIL"
        report["warnings"].append("Hook clearance is not larger than confirmed drawer thickness.")
    if tray_bb.xlen > 210 or tray_bb.ylen > 210:
        report["warnings"].append("Tray may not fit a 220 mm bed with normal slicer margins.")
    if (p.vape_holder_internal_width <= p.vape_measured_width
            or p.vape_holder_internal_length <= p.vape_measured_length):
        report["status"] = "FAIL"
        report["warnings"].append("Vape holder opening is not larger than the measured device.")

    left_bracket = parts["bracket"].translate((-p.bracket_spacing / 2, 0, 0)).val()
    right_bracket = parts["bracket"].translate((p.bracket_spacing / 2, 0, 0)).val()
    report["assembly_checks"] = {
        "tray_left_bracket_interference_mm3": round(parts["tray"].val().intersect(left_bracket).Volume(), 6),
        "tray_right_bracket_interference_mm3": round(parts["tray"].val().intersect(right_bracket).Volume(), 6),
        "bracket_to_bracket_interference_mm3": round(left_bracket.intersect(right_bracket).Volume(), 6),
    }

    # Analytical clearance between the circular holder wall and the closest
    # horizontal capsule-shaped tray slot.
    straight = p.bolt_slot_length - (p.bolt_nominal_diameter + p.bolt_clearance)
    slot_radius = (p.bolt_nominal_diameter + p.bolt_clearance) / 2
    holder_radius = (p.soda_holder_diameter + 2 * p.soda_holder_wall_thickness) / 2
    slot_margins = []
    for bx in (-p.bracket_spacing / 2, p.bracket_spacing / 2):
        for by in (p.bolt_y_near, p.bolt_y_far):
            dx = max(abs(p.soda_center_x - bx) - straight / 2, 0.0)
            dy = abs(p.soda_center_y - by)
            slot_margins.append(math.hypot(dx, dy) - slot_radius - holder_radius)
    report["assembly_checks"]["minimum_can_wall_to_bolt_slot_plan_clearance_mm"] = round(min(slot_margins), 3)
    if min(slot_margins) <= 0:
        report["status"] = "FAIL"
        report["warnings"].append("A mounting slot intersects the can-holder wall in plan view.")

    # Explicitly check that no bolt slot opens into the vape wall and that the
    # new sleeve remains separate from the existing can wall.
    vape_wall = make_vape_wall(p).val()
    z_top = p.tray_bottom_z + p.tray_base_thickness
    can_outer = (
        cq.Workplane("XY").center(p.soda_center_x, p.soda_center_y)
        .circle(holder_outer / 2).extrude(p.vape_holder_depth).translate((0, 0, z_top))
    )
    can_inner = (
        cq.Workplane("XY").center(p.soda_center_x, p.soda_center_y)
        .circle(p.soda_holder_diameter / 2).extrude(p.vape_holder_depth + 1.0)
        .translate((0, 0, z_top))
    )
    can_wall_reference = can_outer.cut(can_inner).val()
    vape_slot_intersection = 0.0
    for bx in (-p.bracket_spacing / 2, p.bracket_spacing / 2):
        for by in (p.bolt_y_near, p.bolt_y_far):
            slot = horizontal_slot_cutter(
                bx, by, z_top - 1.0, 2.0, p.bolt_slot_length,
                p.bolt_nominal_diameter + p.bolt_clearance,
            ).val()
            vape_slot_intersection += vape_wall.intersect(slot).Volume()
    vape_can_intersection = vape_wall.intersect(can_wall_reference).Volume()
    vape_outer_w = p.vape_holder_internal_width + 2 * p.vape_holder_wall_thickness
    vape_outer_l = p.vape_holder_internal_length + 2 * p.vape_holder_wall_thickness
    vape_left = p.vape_center_x - vape_outer_w / 2
    can_right = p.soda_center_x + holder_outer / 2
    report["assembly_checks"].update({
        "vape_wall_to_bolt_slots_interference_mm3": round(vape_slot_intersection, 6),
        "vape_wall_to_can_wall_interference_mm3": round(vape_can_intersection, 6),
        "vape_wall_to_can_wall_plan_gap_mm": round(vape_left - can_right, 3),
        "vape_outer_envelope_mm": [round(vape_outer_w, 3), round(vape_outer_l, 3)],
    })
    if vape_slot_intersection > 0.001 or vape_can_intersection > 0.001:
        report["status"] = "FAIL"
        report["warnings"].append("The vape wall interferes with a bolt slot or the can wall.")

    # Conservative upper-bound mass from fully solid CAD volume. A slicer may
    # reduce thick-body mass with infill, but must not be assumed to do so.
    petg_density_g_cm3 = 1.27
    tpu_density_g_cm3 = 1.15
    tray_mass_g = parts["tray"].val().Volume() / 1000 * petg_density_g_cm3
    bracket_mass_g = parts["bracket"].val().Volume() / 1000 * petg_density_g_cm3
    pad_mass_g = parts["can_pad"].val().Volume() / 1000 * tpu_density_g_cm3
    vape_pad_mass_g = parts["vape_pad"].val().Volume() / 1000 * tpu_density_g_cm3
    total_mass_g = tray_mass_g + 2 * bracket_mass_g + pad_mass_g + vape_pad_mass_g
    y_moment = (
        tray_mass_g * parts["tray"].val().Center().y
        + 2 * bracket_mass_g * parts["bracket"].val().Center().y
        + pad_mass_g * p.soda_center_y
        + vape_pad_mass_g * p.vape_center_y
    )
    report["mass_estimate"] = {
        "basis": "fully solid CAD volume; actual sliced mass depends on wall and infill settings",
        "petg_density_g_cm3": petg_density_g_cm3,
        "tpu_density_g_cm3": tpu_density_g_cm3,
        "tray_g": round(tray_mass_g, 1),
        "each_bracket_g": round(bracket_mass_g, 1),
        "optional_can_pad_g": round(pad_mass_g, 1),
        "optional_vape_pad_g": round(vape_pad_mass_g, 1),
        "assembly_total_g": round(total_mass_g, 1),
        "assembly_center_of_mass_y_mm": round(y_moment / total_mass_g, 1),
    }

    validation_path = REPORT_DIR / "validation_report.json"
    validation_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def write_parameter_snapshot(p: Parameters = P) -> None:
    (REPORT_DIR / "parameters.json").write_text(json.dumps(asdict(p), indent=2), encoding="utf-8")


def main() -> int:
    make_dirs()
    print("Building parametric solids...")
    parts = build_parts(P)
    print("Exporting printable components...")
    files = export_parts(parts, P)
    print("Exporting complete assembly STEP...")
    assembly_path = export_assembly(make_assembly(parts, P))
    files["step_assembly"] = assembly_path
    print("Rendering inspection views...")
    render_paths = render_all(parts, P)
    print("Re-importing and validating solids/meshes...")
    report = validate(parts, files, P)
    write_parameter_snapshot(P)
    print(json.dumps({
        "validation": report["status"],
        "assembly_step": str(assembly_path),
        "renders": [str(p) for p in render_paths],
    }, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
