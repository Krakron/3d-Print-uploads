"""Beginner launcher for this package's drawer-fit parts."""
from pathlib import Path

from customizer import export_custom_parts, load_drawer_settings


ROOT = Path(__file__).resolve().parent
PACKAGE_ID = '02-radio-holder-system'


def main() -> int:
    settings = load_drawer_settings(ROOT / "drawer-settings.json")
    files = export_custom_parts(
        PACKAGE_ID,
        settings,
        ROOT,
        ROOT / "generated-custom-brackets",
    )
    print("Custom parts were written to:")
    print(files["directory"])
    print("Print drawer_fit_coupon_print_oriented.stl first.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
