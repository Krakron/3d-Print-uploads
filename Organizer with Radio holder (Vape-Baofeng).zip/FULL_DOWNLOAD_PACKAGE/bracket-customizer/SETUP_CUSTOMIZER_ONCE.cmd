@echo off
setlocal
cd /d "%~dp0"
echo This one-time setup creates a local Python environment in this folder.
echo Internet access is required to download CadQuery and its dependencies.
echo The pinned CAD package is cadquery==2.5.2.
echo.
set /p CUSTOMIZER_CONFIRM=Type YES to continue, or press Enter to cancel: 
if /I not "%CUSTOMIZER_CONFIRM%"=="YES" (
  echo Setup cancelled. No packages were installed.
  exit /b 1
)
py -3 -m venv .venv
if errorlevel 1 exit /b 1
call ".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 exit /b 1
call ".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
echo Setup complete. Run BUILD_CUSTOM_BRACKETS.cmd next.
pause
