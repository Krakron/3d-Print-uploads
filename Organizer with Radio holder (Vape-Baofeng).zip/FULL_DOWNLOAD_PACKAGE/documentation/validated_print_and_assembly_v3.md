# Radio holder system v3 — print and assembly

## Print the fit test first

Print `radio_body_fit_test_64x43p5mm_print_flat.stl`.  Its opening is
64.0 x 43.5 mm.  Slide it over the widest usable
part of the radio body without forcing it.  The photos establish the maximum width and depth,
but not every corner radius or battery-case bulge.  Stop here and edit the two internal-size
parameters if the collar binds.

## Which mount to use

- The drawer-specific adapter preserves the already successful 21.5 mm hook clearance for the
  measured 20.85 mm dresser front.  It is the preferred part for this drawer.
- The adjustable adapter is for flat, structurally sound panel edges only.  It uses two screws
  so it resists yaw better than a single point.  Its nominal panel range is 5–45 mm; verify the
  available flat contact area before loading it.
- Both use the same removable cradle.  The radio rests on the floor and front rail; the weak
  factory spring belt clip is intentionally unused.

## Hardware

- Each standalone mount: 2 x M5 socket-head screws, 16–20 mm long; 2 x M5 hex nuts; washers as needed.
- Adjustable mount only: 2 x fully threaded M8 x 70 mm bolts, 2 x M8 hex nuts, and 2 printed pressure
  pads.  Add thin rubber/TPU to every wood-contact surface.  Do not tighten hard enough to crush,
  dent, or delaminate the furniture.
- V3 organizer tray: reuse the proven two brackets and four M5 fasteners from v1/v2.

## Print sets

- Tray upgrade only: print `organizer_tray_v3_can_vape_radio_print_flat.stl`; reuse the two proven
  organizer brackets.  The package also includes the bracket STL marked `print_2` if replacements
  are needed.
- Drawer-specific standalone radio mount: print one radio cradle and one 21.5 mm drawer adapter.
- Adjustable standalone radio mount: print one radio cradle, one adjustable adapter, and two
  pressure pads.  The pressure-pad STL contains one puck and is intentionally marked `print_2`.
- TPU pads are optional.  Do not print a rigid PETG pad thicker than specified because it can
  reduce the designed clearance.

## Assembly

1. Load the two M5 nuts into the hex pockets under the adapter shelf.
2. Set the cradle on the shelf with its rear wall against the long adapter plate.
3. Insert the M5 screws through the recessed holes in the cradle floor and tighten until snug.
   The shelf carries the weight; the screws locate the cradle and resist lift/sliding.
4. Cover the recessed screw heads with the optional TPU radio pad.
5. For the adjustable adapter, load the M8 nuts into the inner clamp plate, run both bolts evenly,
   place one pressure pad at each tip, and alternate tightening until the mount cannot rock by hand.

## PETG slicer starting point (0.4 mm nozzle)

- 0.20 mm layers (0.24 mm is acceptable for the fit coupon).
- 5 walls for the cradle/tray; 6 walls for either adapter.
- 6 top and 6 bottom layers.
- 35% gyroid/cubic infill for cradle and tray; 45% for adapters.  Wall count and orientation matter
  more than simply raising infill.
- Print the tray, cradle, collars, and pads as exported.  Print each adapter on its broad side as
  exported so the hook/clamp load stays mainly within continuous roads.
- Supports: none for the tray/cradle/fit collar.  Build-plate-only support may help the recessed
  nut pockets on an adapter depending on bridging calibration.

## Physical test before everyday use

1. Test empty, then with the radio switched off over a pillow or folded towel.
2. Pull upward and sideways gently; confirm the cradle screws, clamp, and drawer hook do not shift.
3. Increase load gradually to the actual radio mass.  Recheck after 1 hour and 24 hours for PETG creep.
4. For the tray, test the combined radio plus sealed can before using an open drink.
5. Keep the drawer stationary.  Moving/slamming the drawer can spill a drink and sharply multiplies
   the load on the printed parts and drawer slides.

Do not charge a hot, swollen, damaged, or unattended battery in a printed holder.  These parts are
prototype furniture accessories, not certified load-rated mounts.
