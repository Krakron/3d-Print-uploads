# Drawer-Mounted Radio Holder - Fixed and Adjustable Mount Options

## Ready-to-paste Creality fields

- Original work: Original
- Price: Free
- Printing technology: FFF
- Suggested category: Tools > Organization
- Tags: radio holder, drawer mount, handheld radio, adjustable clamp, removable mount, equipment organizer, PETG, utility, Baofeng, bottom supported
- License: CC BY-NC-SA 4.0

## Short summary

A bottom-supported handheld-radio cradle with either a fixed dresser-drawer hook or an adjustable flat-edge clamp.

## Full description

This system supports a measured handheld radio from underneath instead of depending on its weak factory belt clip. The radio slides into a deep cradle with a solid floor and side retention. Choose either the fixed 21.5 mm drawer adapter for the measured dresser or the separate two-screw adjustable edge clamp for other sturdy flat panels. The two mounting approaches are alternatives, not parts that must be stacked together. A low-material radio-body coupon helps check the 64 x 43.5 mm internal cradle fit first. An optional organizer-tray variant combines can, vape, radio, and catchall storage. The drawer customizer changes only the fixed adapter hook span; it does not alter the cradle or adjustable clamp. Confirm your radio dimensions and physically test retention before use.

## Creator note

I am still new to CAD and 3D printing. I designed these parts to solve practical problems in my own dresser-and-bed PC setup, then iterated them from real prints and fit checks. Constructive feedback and carefully documented makes are welcome.

## Included files

Bottom-supported cradle, fixed drawer adapter, adjustable edge clamp, two pressure pads, radio-body fit coupon, optional TPU radio pad, optional can/vape/radio tray variant, STEP assemblies, and fixed-hook customizer.

## Required hardware

Cradle-to-adapter joint uses two M5 fasteners and captured nuts. The adjustable adapter uses two fully threaded M8 clamp bolts with printed pressure pads. Verify your actual hardware against the included guide.

## Material and slicer settings

PETG is recommended for structural parts. Start with a 0.4 mm nozzle, 0.20 mm layers, 5 top and bottom layers, and 25-35% gyroid or cubic infill. Use 5-6 walls for load-bearing brackets and 4 walls for trays. More walls are more useful here than extreme infill. TPU is optional only for files explicitly named as pads or shims.

## Print orientation and supports

Print cradle upright on its floor. Print fixed and adjustable adapters on their broad side as supplied. Print pressure pads and radio coupon flat. Use supports only where your slicer preview identifies unavoidable hardware-pocket overhangs.

## Assembly

Select one adapter. Bolt the cradle onto its fully supported shelf, fit any protective pads, and mount it to a stationary edge. On the adjustable clamp, tighten both screws evenly by hand; do not crush the furniture panel.

## Fit-test sequence

1. Print the radio-body coupon. 2. For the fixed mount, print the drawer-hook coupon. 3. Verify hardware and pad fit. 4. Print the chosen adapter and cradle. 5. Test with the radio over a soft surface before mounting at full height.

## Safety and prototype limitations

Compatibility is limited to the measured radio envelope and must be checked. This prototype has no certified load rating. Inspect the cradle floor, bolts, hooks, and clamp pressure regularly, and do not mount where a falling radio could injure someone or damage equipment.

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International

License: CC BY-NC-SA 4.0
Canonical terms: https://creativecommons.org/licenses/by-nc-sa/4.0/

You may share and adapt this work with attribution, for noncommercial use,
provided adaptations are distributed under the same license. This summary is
not a substitute for the full license terms at the URL above.

Attribution guidance: name the model title and identify its creator as the
original Creality Cloud uploader. No personal name or account handle is
invented in this package; the publishing account supplies that identity.
