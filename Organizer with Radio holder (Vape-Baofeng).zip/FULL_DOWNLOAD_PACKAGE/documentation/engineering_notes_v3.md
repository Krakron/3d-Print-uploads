# Engineering notes

The measured radio envelope used here is 62.07 mm maximum photographed width, 40.37 mm depth,
and 157.73 mm body height.  The lower body was photographed at 58.01 mm wide.  The shared opening
is 64.0 x 43.5 mm, leaving 1.93 mm total width clearance and 3.13 mm total depth clearance.

For a screening calculation only, a 0.40 kg can at 57 mm, an assumed (not measured) 0.35 kg radio
at 49 mm, and 0.20 kg of small items at 100 mm create approximately 0.59 N·m static forward moment
about the drawer face.  A simple 2x bump screen is approximately 1.18 N·m.  This is not a verified
rating: the actual radio mass, printed layer bonding, PETG creep, drawer construction, and drawer
slides dominate the real safety margin.

The standalone cradle is intentionally shelf-supported.  Its two M5 fasteners do not carry the
radio weight by friction alone.  The drawer adapter has a broad 135 mm outside contact plate and
twin gussets.  The adjustable version uses two M8 pressure points to reduce yaw, but it remains
suitable only for flat and structurally sound edges.  Physical progressive load testing is required.
